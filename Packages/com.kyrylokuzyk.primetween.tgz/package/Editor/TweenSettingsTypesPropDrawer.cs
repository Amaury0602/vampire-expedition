using JetBrains.Annotations;
using PrimeTween;
using UnityEditor;
using UnityEngine;
using static UnityEditor.EditorGUI;
using static UnityEditor.EditorGUIUtility;

[CustomPropertyDrawer(typeof(TweenSettings<float>)),
 CustomPropertyDrawer(typeof(TweenSettings<Color>)),
 CustomPropertyDrawer(typeof(TweenSettings<Vector2>)),
 CustomPropertyDrawer(typeof(TweenSettings<Vector3>)),
 CustomPropertyDrawer(typeof(TweenSettings<Vector4>)),
 CustomPropertyDrawer(typeof(TweenSettings<Rect>)),
 CustomPropertyDrawer(typeof(TweenSettings<Quaternion>)),
 CustomPropertyDrawer(typeof(TweenSettings<int>))
]
internal class TweenSettingsTypesPropDrawer : PropertyDrawer {
    static readonly GUIContent useStartValueGuiContent = new GUIContent("", "If enabled, the animation will start from the '" + nameof(TweenSettings<float>.startValue) + "'.\n\n" +
                                                                             "If disabled, the current value of an animated property will be used instead ('" + nameof(TweenSettings<float>.startFromCurrent) + "' is true).");

    public override float GetPropertyHeight([NotNull] SerializedProperty property, GUIContent label) {
        if (!property.isExpanded) {
            return singleLineHeight;
        }
        var count = 0;
        float height = 0f;
        property.NextVisible(true); // startFromCurrent
        incrementHeight(); // startValue
        incrementHeight(); // endValue
        property.NextVisible(false);
        var result = height + 0 * (count - 1) + TweenSettingsPropDrawer.getPropHeight(property);
        result += standardVerticalSpacing * 2; // extra space
        return result;

        void incrementHeight() {
            property.NextVisible(false);
            count++; // startFromCurrent
            height += EditorGUI.GetPropertyHeight(property, true);
        }
    }

    public override void OnGUI(Rect position, [NotNull] SerializedProperty property, GUIContent label) {
        var rect = new Rect(position) { height = singleLineHeight };
        PropertyField(rect, property, label);
        if (!property.isExpanded) {
            return;
        }
        rect.y += singleLineHeight + standardVerticalSpacing;
        indentLevel++;

        // startFromCurrent
        property.NextVisible(true);

        // startValue
        {
            const float toggleWidth = 18f;
            var togglePos = new Rect(IndentedRect(rect).x,rect.y, toggleWidth, singleLineHeight);
            bool startFromCurrent;
            int origIndentLevel = indentLevel;
            indentLevel = 0;
            using (var scope = new CustomPropertyScope(togglePos, useStartValueGuiContent, property)) {
                startFromCurrent = !ToggleLeft(togglePos, scope.content, !property.boolValue);
                if (scope.EndChangeCheck()) {
                    property.boolValue = startFromCurrent;
                }
            }
            indentLevel = origIndentLevel;

            property.NextVisible(false);
            var origLabelWidth = labelWidth;
            labelWidth -= toggleWidth;
            using (new DisabledScope(startFromCurrent)) {
                PropertyField(new Rect(rect) { xMin = rect.xMin + toggleWidth }, property, true);
            }
            labelWidth = origLabelWidth;
            moveToNextLine(true);
        }

        // endValue
        property.NextVisible(false);
        PropertyField(rect, property, true);
        moveToNextLine(true);

        // duration
        {
            property.NextVisible(false); // settings
            property.NextVisible(true); // duration
            TweenSettingsPropDrawer.DrawDuration(rect, property);
            moveToNextLine(false);
        }

        TweenSettingsPropDrawer.drawEaseTillEnd(property, ref rect);

        indentLevel--;

        void moveToNextLine(bool includeChildren) {
            rect.y += EditorGUI.GetPropertyHeight(property, includeChildren) + standardVerticalSpacing;
        }
    }
}
