// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable UnusedMember.Global
// ReSharper disable UnusedMethodReturnValue.Global
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using JetBrains.Annotations;
using UnityEngine;
using TweenType = PrimeTween.TweenAnimation.TweenType;

// p1 todo support color gradient
namespace PrimeTween {
    public partial struct Tween {
        /// <summary>Returns the number of alive tweens.</summary>
        /// <param name="onTarget">If specified, returns the number of running tweens on the target. Please note: if the target is specified, this method call has O(n) complexity where n is the total number of running tweens.</param>
        public static int GetTweensCount([CanBeNull] object onTarget = null) {
            PrimeTweenManager.EnsureRunningOnMainThread();
            var manager = PrimeTweenManager.Instance;
            if (onTarget == null && manager.updateDepth == 0) {
                int result = manager.tweensCount;
                #if PRIME_TWEEN_SAFETY_CHECKS && UNITY_ASSERTIONS
                Assert.AreEqual(result, PrimeTweenManager.ProcessAll(null, _ => true, true));
                #endif
                return result;
            }
            return PrimeTweenManager.ProcessAll(onTarget, _ => true, true); // call ProcessAll to filter null tweens
        }

        #if PRIME_TWEEN_EXPERIMENTAL
        public static int GetTweensCapacity() {
            PrimeTweenManager.EnsureRunningOnMainThread();
            var instance = PrimeTweenConfig.Instance;
            if (instance == null) {
                return PrimeTweenManager.customInitialCapacity;
            }
            return instance.currentPoolCapacity;
        }

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom(Double startValue, Double endValue, float duration, [NotNull] Action<Double> onValueChange, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => Custom(new TweenSettings<Double>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)), onValueChange);

        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween Custom(Double startValue, Double endValue, TweenSettings settings, [NotNull] Action<Double> onValueChange) => Custom(new TweenSettings<Double>(startValue, endValue, settings), onValueChange);

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom(TweenSettings<Double> settings, [NotNull] Action<Double> onValueChange)
            => CustomGeneric(PrimeTweenManager.dummyTarget, new NoTargetNoPayload(), settings.ToContainer(), onValueChange, null, TweenType.CustomDouble);

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom<T>([NotNull] T target, Double startValue, Double endValue, float duration, [NotNull] Action<T, Double> onValueChange, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false) where T : class
            => Custom(target, new TweenSettings<Double>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)), onValueChange);

        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween Custom<T>([NotNull] T target, Double startValue, Double endValue, TweenSettings settings, [NotNull] Action<T, Double> onValueChange) where T : class
            => Custom(target, new TweenSettings<Double>(startValue, endValue, settings), onValueChange);

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom<T>([NotNull] T target, TweenSettings<Double> settings, [NotNull] Action<T, Double> onValueChange) where T : class
            => CustomGeneric(target, new NoPayload(), settings.ToContainer(), onValueChange, null, TweenType.CustomDouble);

        /// <inheritdoc cref="CustomGeneric{T,TPayload}"/>
        public static Tween Custom<T, TPayload>([NotNull] T target, TPayload payload, TweenSettings<Double> settings, [NotNull] Action<T, TPayload, Double> onValueChange) where T : class where TPayload : unmanaged
            => CustomGeneric(target, payload, settings.ToContainer(), onValueChange, null, TweenType.CustomDouble);

        /// <inheritdoc cref="AdditiveTweensDoc"/>
        public static Tween CustomAdditive<T>([NotNull] T target, Double deltaValue, TweenSettings settings, [NotNull] Action<T, Double> onDeltaChange, [CanBeNull] Func<T, Double> getCurrentValue = null, bool useDurationAsSpeed = false) where T : class
            => CustomGeneric(target, new AdditivePayload(), new TweenSettings<Double>(default, deltaValue, settings).ToContainer(), onDeltaChange, getCurrentValue, TweenType.CustomDouble, useDurationAsSpeed);
        #endif

        // Euler additive rotations animate a Vector3, but report the delta as a Quaternion because Euler deltas of each update don't sum up to Euler(deltaValue).
        // The generated RotationAdditive(Vector3) methods resolve to this overload because their setters and getters work with Quaternion
        internal static Tween CustomAdditive<T>([NotNull] T target, Vector3 deltaValue, TweenSettings settings, [NotNull] Action<T, Quaternion> onDeltaChange, [CanBeNull] Func<T, Quaternion> getCurrentValue) where T : class
            => CustomGeneric(target, new AdditivePayload(), new TweenSettings<Vector3>(default, deltaValue, settings).ToContainer(), onDeltaChange, getCurrentValue, TweenType.CustomVector3);

        /// <summary>Stops all tweens and sequences.<br/>
        /// If <see cref="onTarget"/> is provided, stops only tweens on this target (stopping a tween inside a Sequence is not allowed).</summary>
        /// <returns>The number of stopped tweens.</returns>
        public static int StopAll([CanBeNull] object onTarget = null) {
            PrimeTweenManager.EnsureRunningOnMainThread();
            // OnFinally() is not invoked here: ProcessAll() would also process and stop the animations started from OnFinally(). The manager invokes it when it releases the stopped animations
            var result = PrimeTweenManager.ProcessAll(onTarget, tween => {
                ref var d = ref tween.data;
                if (d.isInSequence) {
                    if (d.IsMainSequenceRoot()) {
                        // Same as Sequence.Stop(), but without ReportOnFinally()
                        if (new Tween(tween).TryManipulate(false)) {
                            new Sequence(tween.sequence).ReleaseTweens();
                        }
                    }
                    // do nothing with nested tween or sequence. The main sequence root will process it
                } else {
                    tween.managedData.Kill(ref d);
                }
                return true;
            }, false);
            ForceUpdateManagerIfTargetIsNull(onTarget);
            return result;
        }

        /// <summary>Completes all tweens and sequences.<br/>
        /// If <see cref="onTarget"/> is provided, completes only tweens on this target (completing a tween inside a Sequence is not allowed).</summary>
        /// <returns>The number of completed tweens.</returns>
        public static int CompleteAll([CanBeNull] object onTarget = null) {
            PrimeTweenManager.EnsureRunningOnMainThread();
            var manager = PrimeTweenManager.Instance;
            if (manager.updateDepth != 0) {
                manager.completeAllRequested = true;
                manager.completeAllRequestedTarget = onTarget;
                return onTarget == null ? manager.tweensCount : GetTweensCount(onTarget);
            }

            manager.AddNewTweens(_UpdateType.Update);
            manager.AddNewTweens(_UpdateType.LateUpdate);
            manager.AddNewTweens(_UpdateType.FixedUpdate);
            #if PRIME_TWEEN_EXPERIMENTAL
            manager.AddNewTweens(_UpdateType.Manual);
            #endif
            var result = PrimeTweenManager.ProcessAll(onTarget, tween => {
                ref var d = ref tween.data;
                if (d.isInSequence) {
                    if (d.IsMainSequenceRoot()) {
                        new Sequence(tween.sequence).Complete();
                    }
                    // do nothing with nested tween or sequence. The main sequence root will process it
                } else {
                    new Tween(tween).Complete();
                }
                return true;
            }, false, onlyRunning: true);
            ForceUpdateManagerIfTargetIsNull(onTarget);
            return result;
        }

        static void ForceUpdateManagerIfTargetIsNull([CanBeNull] object onTarget) {
            if (onTarget == null) {
                var manager = PrimeTweenManager.Instance;
                if (manager != null) {
                    if (manager.updateDepth == 0) {
                        manager.UpdateTweens(_UpdateType.Update, 0f, 0f);
                        manager.UpdateTweens(_UpdateType.LateUpdate, 0f, 0f);
                        manager.UpdateTweens(_UpdateType.FixedUpdate, 0f, 0f);

                        // user's onComplete can create new tweens, so calling UpdateTweens copies new tweens into running tweens array
                        // Assert.AreEqual(0, manager.tweensUpdate.Count);
                        // Assert.AreEqual(0, manager.tweensLateUpdate.Count); // LateUpdate adds new tweens after update
                        // Assert.AreEqual(0, manager.tweensFixedUpdate.Count);
                    }
                }
            }
        }

        /// <summary>Pauses/unpauses all tweens and sequences.<br/>
        /// If <see cref="onTarget"/> is provided, pauses/unpauses only tweens on this target (pausing/unpausing a tween inside a Sequence is not allowed).</summary>
        /// <returns>The number of paused/unpaused tweens.</returns>
        public static int SetPausedAll(bool isPaused, [CanBeNull] object onTarget = null) {
            PrimeTweenManager.EnsureRunningOnMainThread();
            if (isPaused) {
                return PrimeTweenManager.ProcessAll(onTarget, tween => {
                    if (!tween.data.canManipulate()) {
                        return false; // the parent Sequence controls the pause of nested animations. A paused nested Sequence stops updating its children
                    }
                    if (tween.data.isInSequence && tween.FindMainSequence().data.IsCompleting) {
                        return false; // see Sequence.Complete()
                    }
                    tween.data.TryRollBackJobUpdate();
                    return tween.data.trySetPause(true);
                }, false);
            }
            return PrimeTweenManager.ProcessAll(onTarget, tween => {
                return tween.data.trySetPause(false);
            }, false);
        }

        /// <summary>Please note: delay may outlive the caller (the calling UnityEngine.Object may already be destroyed).
        /// When using this overload, it's user's responsibility to ensure that <see cref="onComplete"/> is safe to execute once the delay is finished.
        /// It's preferable to use the <see cref="Delay{T}"/> overload because it checks if the UnityEngine.Object target is still alive before calling the <see cref="onComplete"/>.</summary>
        /// <param name="warnIfTargetDestroyed">https://github.com/KyryloKuzyk/PrimeTween/discussions/4</param>
        public static Tween Delay(float duration, [CanBeNull] Action onComplete = null, bool useUnscaledTime = false, bool? warnIfTargetDestroyed = null) {
            return DelayInternal(PrimeTweenManager.dummyTarget, duration, onComplete, useUnscaledTime, warnIfTargetDestroyed);
        }
        /// <param name="warnIfTargetDestroyed">https://github.com/KyryloKuzyk/PrimeTween/discussions/4</param>
        public static Tween Delay([NotNull] object target, float duration, [CanBeNull] Action onComplete = null, bool useUnscaledTime = false, bool? warnIfTargetDestroyed = null) {
            return DelayInternal(target, duration, onComplete, useUnscaledTime, warnIfTargetDestroyed);
        }
        static Tween DelayInternal([CanBeNull] object target, float duration, [CanBeNull] Action onComplete, bool useUnscaledTime, bool? warnIfTargetDestroyed) {
            var result = delay_internal(target, duration, useUnscaledTime);
            if (onComplete != null) {
                result?.tween.managedData.OnComplete(onComplete, warnIfTargetDestroyed);
            }
            return result ?? default;
        }

        /// <summary> This is the most preferable overload of all Delay functions:<br/>
        /// - It checks if UnityEngine.Object target is still alive before calling the <see cref="onComplete"/> callback.<br/>
        /// - It allows calling any method on <see cref="target"/> without producing garbage.</summary>
        /// <example>
        /// <code>
        /// Tween.Delay(this, duration: 1f, onComplete: _this =&gt; {
        ///     // Please note: we're using '_this' variable from the onComplete callback. Calling DoSomething() directly will implicitly capture 'this' variable (creating a closure) and generate garbage.
        ///     _this.DoSomething();
        /// });
        /// </code>
        /// </example>
        /// <param name="warnIfTargetDestroyed">https://github.com/KyryloKuzyk/PrimeTween/discussions/4</param>
        public static Tween Delay<T>([NotNull] T target, float duration, [NotNull] Action<T> onComplete, bool useUnscaledTime = false, bool? warnIfTargetDestroyed = null) where T : class {
            var maybeDelay = delay_internal(target, duration, useUnscaledTime);
            if (!maybeDelay.HasValue) {
                return default;
            }
            var delay = maybeDelay.Value;
            delay.tween.managedData.OnComplete(target, onComplete, warnIfTargetDestroyed);
            return delay;
        }

        /// <summary>Same as <see cref="Delay{T}(T,float,Action{T},bool,bool?)"/>, but also passes the <paramref name="payload"/> to the <paramref name="onComplete"/> callback without producing garbage.<br/>
        /// <typeparamref name="TPayload"/> can be any struct without reference type fields, up to 16 bytes.</summary>
        /// <param name="warnIfTargetDestroyed">https://github.com/KyryloKuzyk/PrimeTween/discussions/4</param>
        public static Tween Delay<T, TPayload>([NotNull] T target, TPayload payload, float duration, [NotNull] Action<T, TPayload> onComplete, bool useUnscaledTime = false, bool? warnIfTargetDestroyed = null) where T : class where TPayload : unmanaged {
            if (TweenData.CheckPayloadSize<TPayload>()) {
                var maybeDelay = delay_internal(target, duration, useUnscaledTime);
                if (maybeDelay.HasValue) {
                    var delay = maybeDelay.Value;
                    delay.tween.managedData.OnComplete(target, payload, onComplete, warnIfTargetDestroyed);
                    return delay;
                }
            }
            return default;
        }

        static Tween? delay_internal([CanBeNull] object target, float duration, bool useUnscaledTime) {
            PrimeTweenManager.CheckDuration(target, duration);
            return PrimeTweenManager.DelayWithoutDurationCheck(target, duration, useUnscaledTime, false);
        }

        public static Tween MaterialColor([NotNull] Material target, int propertyId, Color endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialColor(target, propertyId, new TweenSettings<Color>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialColor([NotNull] Material target, int propertyId, Color startValue, Color endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialColor(target, propertyId, new TweenSettings<Color>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialColor([NotNull] Material target, int propertyId, Color endValue, TweenSettings settings) => MaterialColor(target, propertyId, new TweenSettings<Color>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialColor([NotNull] Material target, int propertyId, Color startValue, Color endValue, TweenSettings settings) => MaterialColor(target, propertyId, new TweenSettings<Color>(startValue, endValue, settings));
        public static Tween MaterialColor([NotNull] Material target, int propertyId, TweenSettings<Color> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialColorProperty);

        public static Tween MaterialProperty([NotNull] Material target, int propertyId, float endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialProperty(target, propertyId, new TweenSettings<float>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, float startValue, float endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialProperty(target, propertyId, new TweenSettings<float>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, float endValue, TweenSettings settings) => MaterialProperty(target, propertyId, new TweenSettings<float>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, float startValue, float endValue, TweenSettings settings) => MaterialProperty(target, propertyId, new TweenSettings<float>(startValue, endValue, settings));
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, TweenSettings<float> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialProperty);

        public static Tween MaterialAlpha([NotNull] Material target, int propertyId, float endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialAlpha(target, propertyId, new TweenSettings<float>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialAlpha([NotNull] Material target, int propertyId, float startValue, float endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialAlpha(target, propertyId, new TweenSettings<float>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialAlpha([NotNull] Material target, int propertyId, float endValue, TweenSettings settings) => MaterialAlpha(target, propertyId, new TweenSettings<float>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialAlpha([NotNull] Material target, int propertyId, float startValue, float endValue, TweenSettings settings) => MaterialAlpha(target, propertyId, new TweenSettings<float>(startValue, endValue, settings));
        public static Tween MaterialAlpha([NotNull] Material target, int propertyId, TweenSettings<float> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialAlphaProperty);

        public static Tween MaterialTextureOffset([NotNull] Material target, int propertyId, Vector2 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialTextureOffset(target, propertyId, new TweenSettings<Vector2>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialTextureOffset([NotNull] Material target, int propertyId, Vector2 startValue, Vector2 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialTextureOffset(target, propertyId, new TweenSettings<Vector2>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialTextureOffset([NotNull] Material target, int propertyId, Vector2 endValue, TweenSettings settings) => MaterialTextureOffset(target, propertyId, new TweenSettings<Vector2>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialTextureOffset([NotNull] Material target, int propertyId, Vector2 startValue, Vector2 endValue, TweenSettings settings) => MaterialTextureOffset(target, propertyId, new TweenSettings<Vector2>(startValue, endValue, settings));
        public static Tween MaterialTextureOffset([NotNull] Material target, int propertyId, TweenSettings<Vector2> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialTextureOffset);

        public static Tween MaterialTextureScale([NotNull] Material target, int propertyId, Vector2 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialTextureScale(target, propertyId, new TweenSettings<Vector2>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialTextureScale([NotNull] Material target, int propertyId, Vector2 startValue, Vector2 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialTextureScale(target, propertyId, new TweenSettings<Vector2>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialTextureScale([NotNull] Material target, int propertyId, Vector2 endValue, TweenSettings settings) => MaterialTextureScale(target, propertyId, new TweenSettings<Vector2>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialTextureScale([NotNull] Material target, int propertyId, Vector2 startValue, Vector2 endValue, TweenSettings settings) => MaterialTextureScale(target, propertyId, new TweenSettings<Vector2>(startValue, endValue, settings));
        public static Tween MaterialTextureScale([NotNull] Material target, int propertyId, TweenSettings<Vector2> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialTextureScale);

        public static Tween MaterialProperty([NotNull] Material target, int propertyId, Vector4 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialProperty(target, propertyId, new TweenSettings<Vector4>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, Vector4 startValue, Vector4 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => MaterialProperty(target, propertyId, new TweenSettings<Vector4>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, Vector4 endValue, TweenSettings settings) => MaterialProperty(target, propertyId, new TweenSettings<Vector4>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, Vector4 startValue, Vector4 endValue, TweenSettings settings) => MaterialProperty(target, propertyId, new TweenSettings<Vector4>(startValue, endValue, settings));
        public static Tween MaterialProperty([NotNull] Material target, int propertyId, TweenSettings<Vector4> settings)
            => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = -1 }, settings.ToContainer(), TweenType.MaterialPropertyVector4);

        #if PRIME_TWEEN_PRO && UNITY_2021_1_OR_NEWER
        // p1 todo also add MaterialPropertyBlockColor overload without the int propertyId. Should either search the color property with the [MainColor] ShaderLab attribute. Or use _Color in BiRP and _BaseColor in URP
        /// <summary>
        /// Animates a <see cref="MaterialPropertyBlock"/> property and applies it to the <paramref name="target"/> by calling <see cref="Renderer.SetPropertyBlock(MaterialPropertyBlock)"/>.<br/>
        /// Use this to animate sharedMaterial properties without creating new material instances.<br/><br/>
        ///
        /// NOTE: PrimeTween doesn't reset the MaterialPropertyBlock after animation completion to preserve the animated property at its endValue.<br/>
        /// As a result, directly modifying the <see cref="Material"/> property will have no effect since the MaterialPropertyBlock takes precedence.<br/>
        /// To modify the sharedMaterial property after animation completion, call 'renderer.SetPropertyBlock(null)' (or 'renderer.SetPropertyBlock(null, materialIndex)') to clear the override.
        /// </summary>
        /// <param name="materialIndex">The index of the material in <see cref="Renderer.sharedMaterials"/> to animate via <see cref="Renderer.SetPropertyBlock(MaterialPropertyBlock, int)"/>.
        /// Pass -1 (default) to apply the MaterialPropertyBlock to all materials of the Renderer.</param>
        public static Tween MaterialPropertyBlockColor         ([NotNull] Renderer target, int propertyId,     TweenSettings<Color>   settings, int materialIndex = -1) => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = materialIndex }, settings.ToContainer(), TweenType.MaterialPropertyBlockColorProperty);
        /// <inheritdoc cref="MaterialPropertyBlockColor"/>
        public static Tween MaterialPropertyBlockAlpha         ([NotNull] Renderer target, int propertyId,     TweenSettings<float>   settings, int materialIndex = -1) => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = materialIndex }, settings.ToContainer(), TweenType.MaterialPropertyBlockAlphaProperty);
        /// <inheritdoc cref="MaterialPropertyBlockColor"/>
        public static Tween MaterialPropertyBlockProperty      ([NotNull] Renderer target, int propertyId,     TweenSettings<float>   settings, int materialIndex = -1) => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = materialIndex }, settings.ToContainer(), TweenType.MaterialPropertyBlockProperty);
        /// <inheritdoc cref="MaterialPropertyBlockColor"/>
        public static Tween MaterialPropertyBlockProperty      ([NotNull] Renderer target, int propertyId,     TweenSettings<Vector4> settings, int materialIndex = -1) => AnimateMaterial(target, new MaterialPayload { propId = propertyId, materialIndex = materialIndex }, settings.ToContainer(), TweenType.MaterialPropertyBlockPropertyVector4);
        /// <inheritdoc cref="MaterialPropertyBlockColor"/>
        public static Tween MaterialPropertyBlockTextureScale  ([NotNull] Renderer target, string textureName, TweenSettings<Vector2> settings, int materialIndex = -1) {
            int textureId = Shader.PropertyToID(textureName);
            return AnimateMaterial(target, new MaterialPayload { propId = textureId, stPropId = GetMaterialSTPropId(textureId, textureName), materialIndex = materialIndex }, settings.ToContainer(), TweenType.MaterialPropertyBlockTextureScale);
        }
        /// <inheritdoc cref="MaterialPropertyBlockColor"/>
        public static Tween MaterialPropertyBlockTextureOffset ([NotNull] Renderer target, string textureName, TweenSettings<Vector2> settings, int materialIndex = -1) {
            int textureId = Shader.PropertyToID(textureName);
            return AnimateMaterial(target, new MaterialPayload { propId = textureId, stPropId = GetMaterialSTPropId(textureId, textureName), materialIndex = materialIndex }, settings.ToContainer(), TweenType.MaterialPropertyBlockTextureOffset);
        }
        #endif

        static readonly System.Collections.Generic.Dictionary<int, int> textureIdTo_ST = new System.Collections.Generic.Dictionary<int, int>(10);
        internal static int GetMaterialSTPropId(int textureId, string textureName) {
            if (!textureIdTo_ST.TryGetValue(textureId, out int result)) {
                result = Shader.PropertyToID(textureName + "_ST");
                textureIdTo_ST.Add(textureId, result);
            }
            return result;
        }

        // No 'startFromCurrent' overload because euler angles animation should always have the startValue to prevent ambiguous results
        public static Tween EulerAngles([NotNull] Transform target, Vector3 startValue, Vector3 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => EulerAngles(target, new TweenSettings<Vector3>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween EulerAngles([NotNull] Transform target, Vector3 startValue, Vector3 endValue, TweenSettings settings) => EulerAngles(target, new TweenSettings<Vector3>(startValue, endValue, settings));
        public static Tween EulerAngles([NotNull] Transform target, TweenSettings<Vector3> settings) {
            ValidateEulerAnglesData(ref settings);
            return animate(target, ref settings, TweenType.EulerAngles);
        }

        public static Tween LocalEulerAngles([NotNull] Transform target, Vector3 startValue, Vector3 endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => LocalEulerAngles(target, new TweenSettings<Vector3>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween LocalEulerAngles([NotNull] Transform target, Vector3 startValue, Vector3 endValue, TweenSettings settings) => LocalEulerAngles(target, new TweenSettings<Vector3>(startValue, endValue, settings));
        public static Tween LocalEulerAngles([NotNull] Transform target, TweenSettings<Vector3> settings) {
            ValidateEulerAnglesData(ref settings);
            return animate(target, ref settings, TweenType.LocalEulerAngles);
        }
        static void ValidateEulerAnglesData(ref TweenSettings<Vector3> settings) {
            if (settings.startFromCurrent) {
                settings.startFromCurrent = false;
                Debug.LogWarning("Animating euler angles from the current value may produce unexpected results because there is more than one way to represent the current rotation using Euler angles.\n" +
                                 "'" + nameof(TweenSettings<float>.startFromCurrent) + "' was ignored.\n" +
                                 "More info: https://docs.unity3d.com/ScriptReference/Transform-eulerAngles.html\n");
            }
        }

        // Called from TweenGenerated.cs
        public static Tween Scale([NotNull] Transform target, TweenSettings<float> uniformScaleSettings) {
            var remapped = new TweenSettings<Vector3>(uniformScaleSettings.startValue * Vector3.one, uniformScaleSettings.endValue * Vector3.one, uniformScaleSettings.settings) { startFromCurrent = uniformScaleSettings.startFromCurrent };
            return Scale(target, remapped);
        }
        public static Tween Rotation([NotNull] Transform target, TweenSettings<Vector3> eulerAnglesSettings) => Rotation(target, ToQuaternion(eulerAnglesSettings));
        public static Tween LocalRotation([NotNull] Transform target, TweenSettings<Vector3> localEulerAnglesSettings) => LocalRotation(target, ToQuaternion(localEulerAnglesSettings));
        static TweenSettings<Quaternion> ToQuaternion(TweenSettings<Vector3> s) => new TweenSettings<Quaternion>(Quaternion.Euler(s.startValue), Quaternion.Euler(s.endValue), s.settings) { startFromCurrent = s.startFromCurrent };
        #if TEXT_MESH_PRO_INSTALLED
        public static Tween TextMaxVisibleCharacters([NotNull] TMPro.TMP_Text target, TweenSettings<int> settings) {
            if (target != null) { // creating the tween reports the destroyed target
                var textInfo = Utils.GetTextInfo(target);
                if (textInfo == null) {
                    Debug.LogError("'TMPro.TMP_Text.textInfo' is null!");
                    return default;
                }
                int oldCount = textInfo.characterCount;
                target.ForceMeshUpdate();
                if (oldCount != textInfo.characterCount) {
                    Debug.LogWarning("Please call TMP_Text.ForceMeshUpdate() before animating maxVisibleCharacters.");
                }
            }
            var floatSettings = new TweenSettings<float>(settings.startValue, settings.endValue, settings.settings);
            return AnimateIntAsFloat(target, ref floatSettings, TweenType.TextMaxVisibleCharacters);
        }
        // p2 todo fix this correctly
        static Tween AnimateIntAsFloat(object target, ref TweenSettings<float> settings, TweenType tweenType) {
            if (PrimeTweenManager.Instance.isDestroyed) {
                return default;
            }
            var tween = PrimeTweenManager.FetchTween(settings.settings._updateType);
            ref var rt = ref tween.managedData;
            ref var d = ref tween.data;

            d.startValue.CopyFrom(ref settings.startValue);
            rt.endValueOrDiff.CopyFrom(ref settings.endValue);
            tween.Setup(target, ref settings.settings, settings.startFromCurrent, tweenType, ref rt, ref d);
            return PrimeTweenManager.Animate(ref rt, ref d);
        }
        public static Tween TextMaxVisibleCharactersNormalized([NotNull] TMPro.TMP_Text target, TweenSettings<float>   settings) => animate(target, ref settings, TweenType.TextMaxVisibleCharactersNormalized);
        #endif

        // not generated automatically because GlobalTimeScale() should have 'useUnscaledTime: true'
        public static Tween GlobalTimeScale(Single endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0)
            => GlobalTimeScale(new TweenSettings<float>(endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, true)));
        public static Tween GlobalTimeScale(Single startValue, Single endValue, float duration, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0)
            => GlobalTimeScale(new TweenSettings<float>(startValue, endValue, new TweenSettings(duration, ease, cycles, cycleMode, startDelay, endDelay, true)));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadEndValue)]
        public static Tween GlobalTimeScale(Single endValue, TweenSettings settings) => GlobalTimeScale(new TweenSettings<float>(endValue, settings));
        [EditorBrowsable(EditorBrowsableState.Never)] [Obsolete(ObsoleteMessages.tweenSettingsOverloadStartEndValue)]
        public static Tween GlobalTimeScale(Single startValue, Single endValue, TweenSettings settings) => GlobalTimeScale(new TweenSettings<float>(startValue, endValue, settings));
        public static Tween GlobalTimeScale(TweenSettings<float> settings) {
            clampTimescale(ref settings.startValue);
            clampTimescale(ref settings.endValue);
            if (!settings.settings.useUnscaledTime) {
                Debug.LogWarning("Setting " + nameof(TweenSettings.useUnscaledTime) + " to true to animate Time.timeScale correctly.");
                settings.settings.useUnscaledTime = true;
            }
            return animate(PrimeTweenManager.dummyTarget, ref settings, TweenType.GlobalTimeScale);

            void clampTimescale(ref float value) {
                if (value < 0) {
                    Debug.LogError($"timeScale should be >= 0, but was {value}");
                    value = 0;
                }
            }
        }

        public static Tween TweenTimeScale(Tween tween, TweenSettings<float> settings) => AnimateTimeScale(tween, settings, TweenType.TweenTimeScale);
        static Tween AnimateTimeScale(Tween tween, TweenSettings<float> settings, TweenType tweenType) {
            if (!tween.TryManipulate()) {
                return default;
            }
            if (float.IsNaN(settings.endValue) || !settings.startFromCurrent && float.IsNaN(settings.startValue)) {
                Debug.LogError($"Invalid {nameof(timeScale)}: startValue {settings.startValue}, endValue {settings.endValue}.");
                return default;
            }
            ClampTimeScale(ref settings.startValue);
            ClampTimeScale(ref settings.endValue);
            if (tween.tween.data.HasWait) {
                if (!ValidateWaitTimeScale(settings.endValue) || !ValidateWaitTimeScale(settings.startValue)) {
                    return default;
                }
            }
            var result = animate(tween.tween, ref settings, tweenType);
            Assert.IsTrue(result.isAliveInternal);
            result.tween.blob.Store(new TargetTweenIdPayload { id = tween.id });
            return result;
        }
        public static Tween TweenTimeScale(Sequence sequence, TweenSettings<float> settings) => AnimateTimeScale(sequence.root, settings, TweenType.TweenTimeScaleSequence);

        public static Tween RotationAtSpeed([NotNull] Transform target, Vector3 endValue, float averageAngularSpeed, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => RotationAtSpeed(target, new TweenSettings<Vector3>(endValue, new TweenSettings(averageAngularSpeed, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween RotationAtSpeed([NotNull] Transform target, Vector3 startValue, Vector3 endValue, float averageAngularSpeed, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => RotationAtSpeed(target, new TweenSettings<Vector3>(startValue, endValue, new TweenSettings(averageAngularSpeed, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        static Tween RotationAtSpeed([NotNull] Transform target, TweenSettings<Vector3> settingsVector3) {
            var settings = ToQuaternion(settingsVector3);
            var speed = settings.settings.duration;
            if (speed <= 0) {
                Debug.LogError($"Invalid speed provided to the Tween.{nameof(RotationAtSpeed)}() method: {speed}.");
                return default;
            }
            if (settings.startFromCurrent) {
                settings.startFromCurrent = false;
                settings.startValue = target != null ? target.rotation : Quaternion.identity; // creating the tween reports the destroyed target
            }
            settings.settings.duration = Extensions.CalcDistance(settings.startValue, settings.endValue) / speed;
            return Rotation(target, settings);
        }

        public static Tween LocalRotationAtSpeed([NotNull] Transform target, Vector3 endValue, float averageAngularSpeed, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => LocalRotationAtSpeed(target, new TweenSettings<Vector3>(endValue, new TweenSettings(averageAngularSpeed, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        public static Tween LocalRotationAtSpeed([NotNull] Transform target, Vector3 startValue, Vector3 endValue, float averageAngularSpeed, Easing ease = default, int cycles = 1, CycleMode cycleMode = CycleMode.Restart, float startDelay = 0, float endDelay = 0, bool useUnscaledTime = false)
            => LocalRotationAtSpeed(target, new TweenSettings<Vector3>(startValue, endValue, new TweenSettings(averageAngularSpeed, ease, cycles, cycleMode, startDelay, endDelay, useUnscaledTime)));
        static Tween LocalRotationAtSpeed([NotNull] Transform target, TweenSettings<Vector3> settingsVector3) {
            var settings = ToQuaternion(settingsVector3);
            var speed = settings.settings.duration;
            if (speed <= 0) {
                Debug.LogError($"Invalid speed provided to the Tween.{nameof(LocalRotationAtSpeed)}() method: {speed}.");
                return default;
            }
            if (settings.startFromCurrent) {
                settings.startFromCurrent = false;
                settings.startValue = target != null ? target.localRotation : Quaternion.identity; // creating the tween reports the destroyed target
            }
            settings.settings.duration = Extensions.CalcDistance(settings.startValue, settings.endValue) / speed;
            return LocalRotation(target, settings);
        }

        #if !UNITY_2019_1_OR_NEWER || PHYSICS_MODULE_INSTALLED
        public static Tween RigidbodyMoveRotation(Rigidbody target, TweenSettings<Vector3> eulerAnglesSettings) => RigidbodyMoveRotation(target, ToQuaternion(eulerAnglesSettings));
        #endif

        static Tween AnimateMaterial([CanBeNull] object target, MaterialPayload materialPayload, TweenSettings<TweenAnimation.ValueWrapper> settings, TweenType tweenType) {
            if (PrimeTweenManager.Instance.isDestroyed) {
                return default;
            }
            int materialIndex = materialPayload.materialIndex;
            #if PRIME_TWEEN_PRO && UNITY_2021_1_OR_NEWER
            if (materialIndex != -1 && target is Renderer r && r != null) {
                r.GetSharedMaterials(Utils.sharedMaterialsCache);
                int materialsCount = Utils.sharedMaterialsCache.Count;
                Utils.sharedMaterialsCache.Clear();
                if (materialIndex < -1 || materialIndex >= materialsCount) {
                    Debug.LogError($"Invalid materialIndex: {materialIndex}, Renderer has {materialsCount} materials. Pass -1 to apply the MaterialPropertyBlock to the whole Renderer.", r);
                    return default;
                }
            }
            #endif
            #if UNITY_ASSERTIONS
            int propId = materialPayload.propId;
            if (target is Material material && material != null && !Utils.IsValidMaterialProperty(tweenType, target, propId, materialIndex)) {
                Debug.LogWarning($"Material doesn't have a property with id '{propId}'.", material);
            }
            if (target is Renderer renderer && renderer != null && !Utils.IsValidMaterialProperty(tweenType, target, propId, materialIndex)) {
                Debug.LogWarning($"Renderer's material doesn't have a property with id '{propId}', materialIndex: {materialIndex}.", renderer);
            }
            #endif
            var tween = PrimeTweenManager.FetchTween(settings.settings._updateType);
            ref var d = ref tween.data;
            ref var rt = ref tween.managedData;
            d.startValue = settings.startValue;
            rt.endValueOrDiff = settings.endValue;
            tween.blob.Store(materialPayload);
            tween.Setup(target, ref settings.settings, settings.startFromCurrent, tweenType, ref rt, ref d);
            return PrimeTweenManager.Animate(ref rt, ref d);
        }

        static Tween AnimateGeneric(object target, ref TweenSettings<TweenAnimation.ValueWrapper> settings, TweenType tweenType) {
            var propType = Utils.TweenTypeToTweenData(tweenType).Item1;
            switch (propType) {
                case PropType.Color: {
                    var s = new TweenSettings<Color>(settings.startValue.color, settings.endValue.color, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Vector2: {
                    var s = new TweenSettings<Vector2>(settings.startValue.vector2, settings.endValue.vector2, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Float: {
                    var s = new TweenSettings<float>(settings.startValue.single, settings.endValue.single, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Vector3: {
                    var s = new TweenSettings<Vector3>(settings.startValue.vector3, settings.endValue.vector3, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Vector4: {
                    var s = new TweenSettings<Vector4>(settings.startValue.vector4, settings.endValue.vector4, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Quaternion: {
                    var s = new TweenSettings<Quaternion>(settings.startValue.quaternion, settings.endValue.quaternion, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.Rect: {
                    var s = new TweenSettings<Rect>(settings.startValue.rect, settings.endValue.rect, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                case PropType.ColorGradient: {
                    var s = new TweenSettings<float>(settings.startValue.single, settings.endValue.single, settings.settings);
                    return animate(target, ref s, tweenType);
                }
                default: throw new Exception(propType.ToString());
            }
        }

        /// <summary>Additive tweens animate delta changes instead of absolute values.
        /// This allows multiple additive tweens to animate the same value simultaneously, combining (blending) their changes.</summary>
        /// <param name="deltaValue">The total relative change of the value.</param>
        /// <param name="onDeltaChange">Use to add the delta to the custom value: '(target, delta) =&gt; target.value += delta'. For Quaternion, use 'target.rotation *= delta'.</param>
        /// <param name="getCurrentValue">Use to get the current custom value.<br/>
        /// Applying a delta rounds it to the precision of the value. With the getter, the tween measures how much of each delta the value actually received and carries the remainder to the next update, so the value doesn't drift over time. <see cref="PrimeTweenConfig.warnCustomAdditiveWithoutGetter"/>.</param>
        /// <param name="useDurationAsSpeed">Treat the duration as the average speed, and calculate the duration as 'distance(deltaValue) / speed'. For Quaternion, the distance is the angle in degrees.</param>
        /// <remarks>NOTE: when multiple additive tweens overlap on the same value, each of them can leave a tiny remainder (up to half of the value's floating-point precision) when it completes, and these remainders can accumulate over many thousands of plays.
        /// Don't rely on exact values animated by additive tweens, e.g., don't compare them for equality or round them down with Mathf.FloorToInt().</remarks>
        /// <example><code>
        /// Tween.PositionAdditive(transform, new Vector3(0, 1, 0), duration: 0.5f, cycles: 2, cycleMode: CycleMode.Yoyo);
        /// Tween.CustomAdditive(this, 10f, new TweenSettings(duration: 1f),
        ///     onDeltaChange: static (_this, delta) =&gt; _this.value += delta,
        ///     getCurrentValue: static _this =&gt; _this.value);
        /// </code></example>
        static void AdditiveTweensDoc(object target, object deltaValue, object onDeltaChange, object getCurrentValue, bool useDurationAsSpeed) { }

        /// <summary>Animates custom value. Accessing outside variables from the callbacks creates a closure that allocates garbage. To animate without allocations, use <paramref name="target"/> and optional <paramref name="payload"/>.</summary>
        /// <param name="target">An optional object passed to <paramref name="onValueChange"/> and <paramref name="getCurrentValue"/>.</param>
        /// <param name="payload">An optional struct passed to <paramref name="onValueChange"/> and <paramref name="getCurrentValue"/> without producing garbage. Can be any struct without reference type fields, up to 16 bytes.</param>
        /// <param name="onValueChange">Use to set the custom value.</param>
        /// <param name="getCurrentValue">Use to get the current custom value. Provide it to support <see cref="TweenSettings{T}.startFromCurrent"/> on custom tweens.</param>
        /// <param name="useDurationAsSpeed">Treat the duration as the average speed, and calculate the duration as 'distance(startValue, endValue) / speed'. For Quaternion, the distance is the angle in degrees.</param>
        /// <example><code>
        /// Tween.Custom(this, new TweenSettings&lt;float&gt;(endValue: 1f, duration: 1f),
        ///     onValueChange: static (_this, val) =&gt; _this.value = val,
        ///     getCurrentValue: static _this =&gt; _this.value);
        /// </code>
        /// Use the payload to avoid capturing variables in lambdas:
        /// <code>
        /// public static Tween AnimateMaterialColor(Material target, int propertyId, TweenSettings&lt;Color&gt; settings) {
        ///     return Tween.Custom(target, propertyId, settings,
        ///         onValueChange: static (m, id, color) =&gt; m.SetColor(id, color),
        ///         getCurrentValue: static (m, id) =&gt; m.GetColor(id));
        /// }
        /// </code></example>
        static Tween CustomGeneric<T, TPayload>([NotNull] T target, TPayload payload, TweenSettings<TweenAnimation.ValueWrapper> settings, [NotNull] object onValueChange, [CanBeNull] object getCurrentValue, TweenType tweenType, bool useDurationAsSpeed = false) where T : class where TPayload : unmanaged {
            if (onValueChange == null) {
                Debug.LogError(Constants.onValueChangeNullError);
                return default;
            }
            if (settings.startFromCurrent && getCurrentValue == null) {
                if (useDurationAsSpeed) {
                    Debug.LogError($"'{nameof(getCurrentValue)}' is required to calculate the duration when '{nameof(useDurationAsSpeed)}' is true and the start value is not provided.");
                    return default;
                }
                Debug.LogWarning(Constants.customTweensDontSupportStartFromCurrentWarning);
            }
            if (PrimeTweenManager.Instance.isDestroyed || (!IsAdditive<TPayload>() && !TweenData.CheckPayloadSize<TPayload>())) { // AdditivePayload is bigger than the user payload limit, its size is checked by a test
                return default;
            }
            if (useDurationAsSpeed) {
                var speed = settings.settings.duration;
                if (speed <= 0) {
                    Debug.LogError($"Invalid speed provided to the Tween.{(IsAdditive<TPayload>() ? nameof(CustomAdditive) : nameof(Custom))}() method: {speed}.");
                    return default;
                }
                var propType = Utils.TweenTypeToTweenData(tweenType).Item1;
                var startValue = settings.startValue;
                if (IsAdditive<TPayload>()) {
                    if (propType == PropType.Quaternion) {
                        startValue = Quaternion.identity.ToContainer();
                    }
                } else if (settings.startFromCurrent && !TweenData.IsDestroyedUnityObject(target)) { // creating the tween reports the destroyed target
                    switch (propType) {
                        case PropType.Float:      startValue = InvokeCustomGetter<T, TPayload, float>     (getCurrentValue, target, payload).ToContainer(); break;
                        case PropType.Color:      startValue = InvokeCustomGetter<T, TPayload, Color>     (getCurrentValue, target, payload).ToContainer(); break;
                        case PropType.Vector2:    startValue = InvokeCustomGetter<T, TPayload, Vector2>   (getCurrentValue, target, payload).ToContainer(); break;
                        case PropType.Vector3:    startValue = InvokeCustomGetter<T, TPayload, Vector3>   (getCurrentValue, target, payload).ToContainer(); break;
                        case PropType.Vector4:    startValue = InvokeCustomGetter<T, TPayload, Vector4>   (getCurrentValue, target, payload).ToContainer(); break;
                        case PropType.Quaternion: startValue = InvokeCustomGetter<T, TPayload, Quaternion>(getCurrentValue, target, payload).ToContainer(); break;
                        case PropType.Rect:       startValue = InvokeCustomGetter<T, TPayload, Rect>      (getCurrentValue, target, payload).ToContainer(); break;
                        default: throw new Exception(propType.ToString());
                    }
                    settings.startFromCurrent = false;
                    settings.startValue = startValue;
                }
                var endValue = settings.endValue;
                float distance;
                switch (propType) {
                    case PropType.Float:      distance = Mathf.Abs(endValue.single - startValue.single); break;
                    case PropType.Double:     distance = (float)Math.Abs(endValue.DoubleVal - startValue.DoubleVal); break;
                    case PropType.Vector2:    distance = Vector2.Distance(startValue.vector2, endValue.vector2); break;
                    case PropType.Vector3:    distance = Vector3.Distance(startValue.vector3, endValue.vector3); break;
                    case PropType.Color:
                    case PropType.Rect:
                    case PropType.Vector4:    distance = Vector4.Distance(startValue.vector4, endValue.vector4); break;
                    case PropType.Quaternion: distance = Quaternion.Angle(startValue.quaternion, endValue.quaternion); break;
                    default: throw new Exception(propType.ToString());
                }
                settings.settings.duration = distance / speed;
            }
            var tween = PrimeTweenManager.FetchTween(settings.settings._updateType);
            ref var rt = ref tween.managedData;
            ref var d = ref tween.data;

            d.startValue = settings.startValue;
            rt.endValueOrDiff = settings.endValue;
            if (IsAdditive<TPayload>()) {
                d.isAdditive = true;
                AdditivePayload iniPayload = default;
                if (onValueChange is Action<T, Quaternion>) {
                    iniPayload.err.w = 1f; // Quaternion.identity
                }
                tween.blob.Store(iniPayload);
                tween.customGetter = getCurrentValue;
                if (getCurrentValue == null && PrimeTweenManager.Instance.warnCustomAdditiveWithoutGetter) {
                    Debug.LogWarning($"{nameof(CustomAdditive)}() is created without '{nameof(getCurrentValue)}'. Without the getter, the animated value accumulates floating-point rounding errors over time. " +
                                     $"{Constants.buildWarningCanBeDisabledMessage(nameof(PrimeTweenConfig.warnCustomAdditiveWithoutGetter))}", target as UnityEngine.Object);
                }
            } else if (HasCustomPayload<TPayload>()) {
                tween.blob.Store(payload);
            }

            if (getCurrentValue != null && !IsAdditive<TPayload>()) {
                tween.customGetter = getCurrentValue;
                tween.customGetterInvoker = (OnValueChangeDelegate)((ref TweenData rt2, ref UnmanagedTweenData d2) => {
                    var _getter = rt2.cold.customGetter;
                    var _target = rt2.target as T;
                    TPayload _payload = HasCustomPayload<TPayload>() ? rt2.cold.blob.Load<TPayload>() : default;
                    switch (d2.propType) {
                        case PropType.Float:      d2.startValue = InvokeCustomGetter<T, TPayload, float>     (_getter, _target, _payload).ToContainer(); break;
                        case PropType.Color:      d2.startValue = InvokeCustomGetter<T, TPayload, Color>     (_getter, _target, _payload).ToContainer(); break;
                        case PropType.Vector2:    d2.startValue = InvokeCustomGetter<T, TPayload, Vector2>   (_getter, _target, _payload).ToContainer(); break;
                        case PropType.Vector3:    d2.startValue = InvokeCustomGetter<T, TPayload, Vector3>   (_getter, _target, _payload).ToContainer(); break;
                        case PropType.Vector4:    d2.startValue = InvokeCustomGetter<T, TPayload, Vector4>   (_getter, _target, _payload).ToContainer(); break;
                        case PropType.Quaternion: d2.startValue = InvokeCustomGetter<T, TPayload, Quaternion>(_getter, _target, _payload).ToContainer(); break;
                        case PropType.Rect:       d2.startValue = InvokeCustomGetter<T, TPayload, Rect>      (_getter, _target, _payload).ToContainer(); break;
                        default: throw new Exception(d2.propType.ToString());
                    }
                });
            }

            tween.customOnValueChange = onValueChange;
            tween.onValueChange = (ref TweenData rt2, ref UnmanagedTweenData d2) => {
                if (d2.isUpdating) {
                    Debug.LogError(Constants.recursiveCallError);
                    return;
                }

                var _target = rt2.target as T;
                object _onValueChange = rt2.cold.customOnValueChange;
                try {
                    d2.isUpdating = true;
                    if (IsAdditive<TPayload>()) {
                        // Additive tweens report the delta since the previous update.
                        // Applying the delta to the target rounds to the target's precision (e.g., 'position += delta' loses 0.0001 at x=100000), so over many updates the target drifts.
                        // To prevent the drift, the getter measures what the target actually absorbed, and the remainder is carried to the next update (Kahan summation on the target).
                        var additivePayload = rt2.cold.blob.Load<AdditivePayload>();
                        float t = d2.easedInterpolationFactor;
                        float prevT = additivePayload.prevT;
                        ref var err = ref additivePayload.err;
                        object _getter = rt2.cold.customGetter;
                        // The delta is calculated in double because the product and the difference of two floats are (nearly) exact in double. So the only rounding left is the conversion of the deltaVal to float, and it's carried to the next update in err
                        var diff = rt2.endValueOrDiff;
                        double dx = (double)diff.x * t - (double)diff.x * prevT + err.x, dy = (double)diff.y * t - (double)diff.y * prevT + err.y, dz = (double)diff.z * t - (double)diff.z * prevT + err.z, dw = (double)diff.w * t - (double)diff.w * prevT + err.w;
                        var deltaVal = new TweenAnimation.ValueWrapper { x = (float)dx, y = (float)dy, z = (float)dz, w = (float)dw };
                        TweenAnimation.ValueWrapper beforeVal = default, afterVal = default;
                        bool isMeasured = false, isLinear = true;
                        switch (d2.propType) {
                            case PropType.Float:   { var getter = _getter as Func<T, float>;   if (getter != null) { beforeVal = getter(_target).ToContainer(); } InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), deltaVal.single);  if (getter != null) { afterVal = getter(_target).ToContainer(); isMeasured = true; } break; }
                            case PropType.Color:   { var getter = _getter as Func<T, Color>;   if (getter != null) { beforeVal = getter(_target).ToContainer(); } InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), deltaVal.color);   if (getter != null) { afterVal = getter(_target).ToContainer(); isMeasured = true; } break; }
                            case PropType.Vector2: { var getter = _getter as Func<T, Vector2>; if (getter != null) { beforeVal = getter(_target).ToContainer(); } InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), deltaVal.vector2); if (getter != null) { afterVal = getter(_target).ToContainer(); isMeasured = true; } break; }
                            case PropType.Vector4: { var getter = _getter as Func<T, Vector4>; if (getter != null) { beforeVal = getter(_target).ToContainer(); } InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), deltaVal.vector4); if (getter != null) { afterVal = getter(_target).ToContainer(); isMeasured = true; } break; }
                            case PropType.Rect:    { var getter = _getter as Func<T, Rect>;    if (getter != null) { beforeVal = getter(_target).ToContainer(); } InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), deltaVal.rect);    if (getter != null) { afterVal = getter(_target).ToContainer(); isMeasured = true; } break; }
                            case PropType.Vector3:
                                if (_onValueChange is Action<T, Vector3>) {
                                                     var getter = _getter as Func<T, Vector3>; if (getter != null) { beforeVal = getter(_target).ToContainer(); } InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), deltaVal.vector3); if (getter != null) { afterVal = getter(_target).ToContainer(); isMeasured = true; }
                                } else {
                                    // Euler rotation: composing Euler(delta) of each update is not Euler(sum of deltas) when more than one axis is animated
                                    var getter = _getter as Func<T, Quaternion>; Quaternion before = getter?.Invoke(_target) ?? default; Quaternion delta = err.quaternion * Quaternion.Inverse(Quaternion.Euler(TweenData.Vector3Val(d2.startValue, prevT, rt2.endValueOrDiff))) * Quaternion.Euler(TweenData.Vector3Val(d2.startValue, t, rt2.endValueOrDiff));
                                                                                                                                                                  InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), delta);            if (getter != null) { err.quaternion = AdditiveErr(before, getter(_target), delta); }
                                    isLinear = false;
                                }
                                break;
                            case PropType.Double:     { var getter = _getter as Func<T, double>; double before = getter?.Invoke(_target) ?? default; double delta = TweenData.DoubleVal(d2.startValue, t, rt2.endValueOrDiff) - TweenData.DoubleVal(d2.startValue, prevT, rt2.endValueOrDiff) + err.DoubleVal;
                                                                                                                                                                  InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), delta);            if (getter != null) { double after = getter(_target); double e = delta - (after - before); double bound = Math.Max(Math.Max(Math.Abs(before), Math.Abs(after)), Math.Abs(delta)) * 4.5e-16; err.DoubleVal = Math.Abs(e) <= bound && bound <= double.MaxValue ? e : 0; } isLinear = false; break; }
                            // err is the rotation the target missed, so applying 'target * err * step' catches up. Assumes that onDeltaChange multiplies from the right: 'rotation *= delta'
                            case PropType.Quaternion: { var getter = _getter as Func<T, Quaternion>; Quaternion before = getter?.Invoke(_target) ?? default; Quaternion delta = err.quaternion * Quaternion.Inverse(TweenData.QuaternionVal(d2.startValue, prevT, rt2.endValueOrDiff)) * TweenData.QuaternionVal(d2.startValue, t, rt2.endValueOrDiff);
                                                                                                                                                                  InvokeCustomOnValueChange(_onValueChange, _target, default(TPayload), delta);            if (getter != null) { err.quaternion = AdditiveErr(before, getter(_target), delta); } isLinear = false; break; }
                            default: throw new Exception(d2.propType.ToString());
                        }
                        if (isLinear) {
                            // without the getter, assume the target absorbed the float delta exactly
                            err = isMeasured
                                ? new TweenAnimation.ValueWrapper { x = AdditiveErr(dx, beforeVal.x, afterVal.x), y = AdditiveErr(dy, beforeVal.y, afterVal.y), z = AdditiveErr(dz, beforeVal.z, afterVal.z), w = AdditiveErr(dw, beforeVal.w, afterVal.w) }
                                : new TweenAnimation.ValueWrapper { x = (float)(dx - deltaVal.x), y = (float)(dy - deltaVal.y), z = (float)(dz - deltaVal.z), w = (float)(dw - deltaVal.w) };
                        }
                        additivePayload.prevT = t;
                        rt2.cold.blob.Store(additivePayload);
                    } else {
                        TPayload _payload = HasCustomPayload<TPayload>() ? rt2.cold.blob.Load<TPayload>() : default;
                        switch (d2.propType) {
                            case PropType.Float:      InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.FloatVal     (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Color:      InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.ColorVal     (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Vector2:    InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.Vector2Val   (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Vector3:    InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.Vector3Val   (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Vector4:    InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.Vector4Val   (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Double:     InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.DoubleVal    (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Quaternion: InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.QuaternionVal(d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            case PropType.Rect:       InvokeCustomOnValueChange(_onValueChange, _target, _payload, TweenData.RectVal      (d2.startValue, d2.easedInterpolationFactor, rt2.endValueOrDiff)); break;
                            default: throw new Exception(d2.propType.ToString());
                        }
                    }
                } finally {
                    d2.isUpdating = false;
                }
            };

            tween.Setup(target, ref settings.settings, settings.startFromCurrent && getCurrentValue != null, tweenType, ref rt, ref d);
            return PrimeTweenManager.Animate(ref rt, ref d);
        }

        internal struct NoPayload { }
        internal struct NoTargetNoPayload { }
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential, Pack = 4)] // ValueWrapper.DoubleVal aligns it to 8 bytes, padding it from 20 to 24
        internal struct AdditivePayload {
            // Storing the eased t instead of the previous value leaves room for err. Incremental cycles are accumulated in the eased t, so the previous value can be recomputed from it
            internal float prevT;
            internal TweenAnimation.ValueWrapper err;
        }

        // err only compensates the rounding, which is below 2 ulps of the values involved. A bigger err means the setter didn't apply the delta right away (e.g., Rigidbody.MovePosition()), clamped it, or multiplied the rotation from the left, or the getter returned a non-finite value.
        // Carrying such err to the next update would apply the delta again, so it's discarded
        static float AdditiveErr(double delta, float before, float after) {
            double err = delta - ((double)after - before);
            double bound = Math.Max(Math.Max(Math.Abs((double)before), Math.Abs((double)after)), Math.Abs(delta)) * 2.4e-7;
            return Math.Abs(err) <= bound && bound <= float.MaxValue ? (float)err : 0f;
        }

        static Quaternion AdditiveErr(Quaternion before, Quaternion after, Quaternion delta) {
            var err = Quaternion.Normalize(Quaternion.Inverse(after) * before * delta);
            // the rounding is a rotation of ~1e-7 radians
            return Math.Abs(err.x) + Math.Abs(err.y) + Math.Abs(err.z) <= 1e-5f ? err : Quaternion.identity;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool HasCustomPayload<TPayload>() => typeof(TPayload) != typeof(NoPayload) && typeof(TPayload) != typeof(NoTargetNoPayload) && typeof(TPayload) != typeof(AdditivePayload);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool IsAdditive<TPayload>() => typeof(TPayload) == typeof(AdditivePayload);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static TVal InvokeCustomGetter<T, TPayload, TVal>(object getter, T target, TPayload payload) where T : class where TPayload : unmanaged {
            if (typeof(TPayload) == typeof(NoPayload)) {
                return (getter as Func<T, TVal>)(target);
            } else if (typeof(TPayload) == typeof(NoTargetNoPayload)) {
                return (getter as Func<TVal>)();
            } else {
                return (getter as Func<T, TPayload, TVal>)(target, payload);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static void InvokeCustomOnValueChange<T, TPayload, TVal>(object onValueChange, T target, TPayload payload, TVal val) where T : class where TPayload : unmanaged {
            if (typeof(TPayload) == typeof(NoPayload) || typeof(TPayload) == typeof(AdditivePayload)) {
                (onValueChange as Action<T, TVal>)(target, val);
            } else if (typeof(TPayload) == typeof(NoTargetNoPayload)) {
                (onValueChange as Action<TVal>)(val);
            } else {
                (onValueChange as Action<T, TPayload, TVal>)(target, payload, val);
            }
        }
    }
}
