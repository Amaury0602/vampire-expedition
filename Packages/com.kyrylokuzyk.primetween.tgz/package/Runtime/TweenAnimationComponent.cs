#if PRIME_TWEEN_PRO
#if TEXT_MESH_PRO_INSTALLED
using TMPro;
#endif
#if !UNITY_2019_1_OR_NEWER || UNITY_UGUI_INSTALLED
using UnityEngine.UI;
#endif
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading;
using JetBrains.Annotations;
using UnityEngine;
using UnityEngine.Events;

namespace PrimeTween {
    /// <summary>A component that exposes <see cref="TweenAnimation"/> to the scene. Consider using it if you need to reference the animation from other scripts or animations in the scene.<br/>
    /// - Allows authoring and previewing complex animation sequences in the Inspector without writing any code.<br/>
    /// - Allows an animation to be referenced in a scene and played from other MonoBehaviours or UnityEvents.<br/>
    /// - Can play an animation in response to Unity messages like OnEnable and OnDisable.<br/></summary>
    [PublicAPI, SelectionBase]
    public class TweenAnimationComponent : MonoBehaviour {
        [SerializeField] public
            #if !UNITY_6000_5_OR_NEWER
            new
            #endif
            TweenAnimation animation = new TweenAnimation();
        [SerializeField] public UnityMessageAction onEnable;
        [SerializeField] public UnityMessageAction onDisable;

        /// <summary>Defines the action to perform when a Unity message like OnEnable or OnDisable is invoked.</summary>
        public enum UnityMessageAction {
            None, Trigger, SetStateTrue, SetStateFalse, Stop, Reset, Complete
        }

        [EditorBrowsable(EditorBrowsableState.Never)] public void ___Complete()    => GetAnimation()?.Complete();
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___SetPaused(bool isPaused)      { if (GetAnimation() is TweenAnimation a) a.isPaused = isPaused; }
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___SetProgressTotal(float value) { if (GetAnimation() is TweenAnimation a) a.progressTotal = value; }
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___SetState(bool newState)       { if (GetAnimation() is TweenAnimation a) a.state = newState; }
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___Stop()        => GetAnimation()?.Stop();
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___ToggleState() => GetAnimation()?.ToggleState();
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___Trigger()     => GetAnimation()?.Trigger();

        [CanBeNull]
        TweenAnimation GetAnimation() {
            if (animation == null) {
                Debug.LogError($"{nameof(animation)} is null.", this);
            }
            return animation;
        }
        internal const string selfReferenceError = "It's not allowed to reference '" + nameof(TweenAnimationComponent) + "' from itself or have a circular reference in the hierarchy.";

        void OnEnable() => ApplyBehaviour(onEnable);
        void OnDisable() {
            bool warnTweenOnDisabledTarget = PrimeTweenConfig.warnTweenOnDisabledTarget;
            PrimeTweenConfig.warnTweenOnDisabledTarget = false;
            ApplyBehaviour(onDisable);
            PrimeTweenConfig.warnTweenOnDisabledTarget = warnTweenOnDisabledTarget;
        }

        void ApplyBehaviour(UnityMessageAction behaviour) {
            #if UNITY_EDITOR
            if (PrimeTweenManager._playModeState == UnityEditor.PlayModeStateChange.ExitingPlayMode) {
                return;
            }
            #endif
            var a = GetAnimation();
            if (a == null) {
                return;
            }
            switch (behaviour) {
                case UnityMessageAction.None:
                    break;
                case UnityMessageAction.Trigger:
                    a.Trigger();
                    break;
                case UnityMessageAction.SetStateTrue:
                    a.state = true;
                    break;
                case UnityMessageAction.SetStateFalse:
                    a.state = false;
                    break;
                case UnityMessageAction.Stop:
                    a.Stop();
                    break;
                case UnityMessageAction.Reset:
                    a.Reset();
                    break;
                case UnityMessageAction.Complete:
                    a.Complete();
                    break;
                default:
                    Debug.LogError($"Invalid {nameof(UnityMessageAction)}: {behaviour}.", this);
                    break;
            }
        }
    }

    /// <summary>A serializable animation which allows authoring and previewing complex animation sequences in the Inspector without writing any code.<br/>
    /// - Allows creating animations right where you need them with no need to set up references in a scene.<br/>
    /// - If animation is reversible, allows you to change the direction of the animation by setting 'state'. No need to keep track of the state yourself, simply choose a new desired direction at any time.<br/>
    /// - Provides ways to tweak how an animation responds to interruptions with <see cref="InterruptionMode"/>.<br/>
    /// <example>
    /// <code>
    /// // Add TweenAnimation to your script, then set the animation up in the Inspector.
    /// [SerializeField] TweenAnimation doorAnimation = new TweenAnimation();
    ///
    /// void Update() {
    ///     if (Input.GetKeyDown(KeyCode.Space)) {
    ///         // Play the animation in response to gameplay events.
    ///         doorAnimation.Trigger();
    ///     }
    /// }
    /// </code>
    /// </example>
    /// </summary>
    [Serializable, PublicAPI] 
    public partial class TweenAnimation : ISerializationCallbackReceiver { // p1 todo add OnComplete?
        // p1 todo add support for TextAnimator typewriter
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        [SerializeField] public List<Data> animations = new List<Data>();

        // 'isReversible' and 'cycles == -1' keep the serialized format of older versions, so older versions can still open the animations saved by this version. They take precedence over '_animationType', which only matters for Overlapping
        [Obsolete("use '" + nameof(animationType) + "' instead.")]
        [SerializeField, HideInInspector] public bool isReversible;
        [SerializeField] internal AnimationType _animationType;

        public AnimationType animationType {
            #pragma warning disable CS0618
            get => GetAnimationType(isReversible, cycles, _animationType);
            set => SetAnimationType(value, ref _animationType, ref isReversible, ref cycles);
            #pragma warning restore CS0618
        }

        internal static void SetAnimationType(AnimationType value, ref AnimationType stored, ref bool isReversible, ref int cycles) {
            // Storing only Overlapping limits any type change to two of the three serialized fields, so the Inspector can link both of them for the prefab Revert/Apply
            stored = value == AnimationType.Overlapping ? AnimationType.Overlapping : AnimationType.Simple;
            isReversible = value == AnimationType.Reversible;
            if (value == AnimationType.Infinite) {
                cycles = -1;
            } else if (cycles == -1) {
                cycles = 1;
            }
        }

        internal static AnimationType GetAnimationType(bool isReversible, int cycles, AnimationType stored) {
            if (isReversible) {
                return AnimationType.Reversible;
            }
            if (stored == AnimationType.Overlapping) {
                return AnimationType.Overlapping;
            }
            return cycles == -1 ? AnimationType.Infinite : AnimationType.Simple;
        }

        /// <summary>Defines how <see cref="TweenAnimation"/> responds to <see cref="state"/> changes and <see cref="Trigger"/>.</summary>
        public enum AnimationType : byte {
            [Tooltip("Plays the animation from the beginning. Triggering the animation while it's playing applies '" + nameof(interruptionMode) + "'.")]
            Simple,
            [Tooltip("Use for toggle animations (e.g., open/close or show/hide).\n\n" +
                     "Set 'state = true' to play forward and 'state = false' to reverse — no need for a separate direction variable. Or use 'Trigger()' to toggle the current state.")]
            Reversible,
            [Tooltip("Plays the animation infinitely. '" + nameof(cycles) + "' is always -1.")]
            Infinite,
            [Tooltip("Triggering the animation while it's playing plays a new animation on top of the playing one. The previous animation continues playing until its end and can no longer be controlled.\n\n" +
                     "Use with additive tweens to blend and accumulate their changes. Additive tweens also accumulate when a completed animation is played again, instead of restarting from the initial value.\n\n" +
                     "Overlapping animations can't be paused and ignore '" + nameof(interruptionMode) + "'.")]
            Overlapping
        }

        /// <summary>See <see cref="Trigger"/> method's documentation to know when the <see cref="InterruptionMode"/> is applied.</summary>
        [Tooltip("Controls how the animation behaves when interrupted.")]
        [SerializeField] public InterruptionMode interruptionMode;

        [Tooltip(Constants.cyclesTooltip)]
        [SerializeField] public int cycles = 1;

        [Tooltip("Controls how the animation behaves with multiple cycles or multiple successive plays.")]
        [SerializeField] public Sequence.SequenceCycleMode cycleMode; // p2 todo if sequenceEase is Linear or Default, Yoyo and Rewind are the same. I can collapse these options into one enum in this case

        [Tooltip("If enabled, triggering the animation again while it's already playing will be ignored.")]
        [SerializeField] public bool ignoreDuplicateTrigger;

        [Tooltip("Instantly resets the animation to the beginning upon completion.")]
        [SerializeField] public bool resetOnCompletion;

        [Tooltip("Easing curve of the entire '" + nameof(TweenAnimation) + "'. Different easing curves produce a different animation 'feeling'.\n\n" +
                 "Easing is clamped to [0:1] range and is applied to the whole animation's timeline.")]
        [SerializeField] public Ease sequenceEase = Ease.Linear;

        [Tooltip(Constants.unscaledTimeTooltip)]
        [SerializeField] public bool useUnscaledTime;

        [Tooltip(Constants.updateTypeTooltip)]
        [SerializeField] internal _UpdateType _updateType;

        [Tooltip("Custom timescale.")]
        [SerializeField] internal float _timeScale = 1f;

        [SerializeField] internal UnityEngine.Object context;



        #if UNITY_EDITOR
        [NonSerialized] ValueWrapper?[][] _iniValues;
        [NonSerialized] internal HeaderData[] _headers;

        /// p2 todo headers should display "---" when multi-editing different animations
        /// p2 todo: add custom tween target name and property name; add material property name
        internal struct HeaderData {
            internal Operation operation;
            internal TweenType tweenType;
            internal string targetName;
            internal GUIContent guiContent;
            internal float insertionTime;
            internal float duration;
            internal int cycles;
            internal string eventNames;
        }
        #endif

        /// <summary>Controls the Unity event function that updates the animation. The default is MonoBehaviour.Update().</summary>
        public UpdateType updateType { get => new UpdateType(_updateType); set => _updateType = value.enumValue; }

        [NonSerialized] bool _state;

        /// <summary>The logical state of the animation. Instead of keeping track of the animation state manually, you can rely on animation state directly.<br/>
        /// State means different things depending on the animation type. Changing state applies <see cref="interruptionMode"/>.<br/><br/>
        /// Simple animations: returns <c>true</c> if an animation is currently playing.<br/>
        /// Infinite animations: returns <c>true</c> if an animation is currently playing and NOT being interrupted by <see cref="interruptionMode"/>.<br/>
        /// Reversible animations (<see cref="AnimationType.Reversible"/>): returns <c>true</c> if the animation is moving forward OR already at the end. Changing state changes animation direction.<br/>
        ///
        /// <example>
        /// <code>
        /// [SerializeField] TweenAnimation doorAnimation = new TweenAnimation();
        /// [SerializeField] TweenAnimation infiniteGlowAnimation = new TweenAnimation();
        ///
        /// public void SetDoorState(bool isOpen) {
        ///     // Apply the animation state with no additional checks. TweenAnimation will only play when the state changes
        ///     doorAnimation.state = isOpen;
        /// }
        ///
        /// public void EnableGlow(bool isEnabled) {
        ///     // Using InterruptionMode.Default will seamlessly transition the infinite animation between active and inactive states
        ///     infiniteGlowAnimation.state = isEnabled;
        /// }
        /// </code>
        /// </example>
        /// </summary>
        public bool state {
            get {
                if (animationType == AnimationType.Reversible
                    || (animationType == AnimationType.Infinite && isAlive)
                    ) {
                    return _state;
                }

                return isAlive;
            }
            set {
                if (!TryManipulate()) {
                    return;
                }
                if (isAlive && !_sequence.root.ValidateIsNotCompleting()) {
                    return;
                }
                if (state != value) {
                    if (isAlive) {
                        // Interrupt() sets the state itself. For example, a simple animation completed by the interruption keeps its _state true
                        if (!Interrupt(value)) {
                            return;
                        }
                    } else {
                        if (animationType == AnimationType.Overlapping) {
                            SetState(false); // additive tweens accumulate on top of the completed play instead of reverting its delta
                        }
                        CreateSequenceAndApplyDirection(value);
                        SetState(value);
                    }
                    Assert.IsTrue(state == value || !isAlive); // a callback can stop a non-reversible animation while it's being created
                }
            }
        }

        // returns false if the interruption is not supported
        bool Interrupt(bool newState) {
            Assert.IsTrue(isAlive);
            Assert.IsTrue(CanManipulate());
            SanitiseInterruptionMode(animationType, ref interruptionMode);
            if (animationType == AnimationType.Infinite) {
                if (newState) {
                    _sequence.SetRemainingCycles(-1);
                    SetState(true);
                } else {
                    if (interruptionMode == InterruptionMode.Reset) {
                        Reset();
                    } else {
                        // StopAtStart
                        if (cycleMode == Sequence.SequenceCycleMode.Restart) {
                            if (Application.isPlaying && HasAdditiveTweens(_sequence)) {
                                Log(LogType.Error, additiveInfiniteRestartError);
                                return false;
                            }
                            _sequence.SetRemainingCycles(1);
                        } else {
                            _sequence.SetRemainingCycles(false);
                        }
                        SetState(false);
                    }
                }
            } else if (animationType == AnimationType.Reversible) {
                if (interruptionMode == InterruptionMode.Complete) {
                    // The new sequence assumes the targets are where it begins (the start if playing forward, the end if backward), so additive tweens of the interrupted sequence move the targets there first.
                    // 'toEnd' is relative to the playback direction, which is reversed if the sequence is inverted
                    ResetAdditiveTweens(applyValues: true, _sequence.root.tween, _sequence.root.tween.data.isSequenceInverted ^ !newState);
                    if (!isAlive) {
                        return false;
                    }
                    _sequence.Stop();
                    CreateSequenceAndApplyDirection(newState);
                    SetState(newState);
                    Complete();
                } else {
                    // Rewind
                    _sequence.timeScale *= -1f;
                    SetState(!state);
                }
            } else { // simple or overlapping
                if (newState) {
                    Debug.LogError("Animation is in an invalid state. It was alive while setting 'state = true'. Please file a bug report: https://github.com/KyryloKuzyk/PrimeTween/issues");
                } else {
                    if (animationType == AnimationType.Simple && interruptionMode == InterruptionMode.Complete) {
                        Complete();
                    } else {
                        Reset();
                    }
                }
            }
            return true;
        }

        [System.Diagnostics.Conditional("_")]
        void print(string msg, UnityEngine.Object ctx = null) {
            // Debug.Log($"[{Time.frameCount}]  {(context != null ? context.name : string.Empty)}  {msg} ", ctx ?? context);
        }

        internal void SetState(bool? value, int depth = 0) {
            if (depth > 32) {
                Debug.LogError(TweenAnimationComponent.selfReferenceError);
                return;
            }

            // early exiting is wrong because nested animation's nestedTweenAnimationIsReversed might have changed
            // also, nested animation can be animated independently while parent was not running. So we need to re-sync the state
            // if (_state == value) {
            //     return;
            // }

            bool newVal = value ?? false;
            /*if (_state != newVal) {
                print($"SetState:{newVal}");
            }*/
            _state = newVal;

            // Set recursively on all nested reversible animations
            if (animations != null) {
                foreach (var data in animations) {
                    if (data.tweenType == TweenType.TweenAnimationComponent
                        && data.operation != Operation.Disabled
                        && data.targets != null
                        && data.targets.Count > 0
                        && data.targets[0] is TweenAnimationComponent component
                        && component != null
                        && component.animation is TweenAnimation nestedAnimation
                        && nestedAnimation != this
                        && nestedAnimation.animationType == AnimationType.Reversible
                       ) {
                        bool? nestedState = value.HasValue ? value.Value ^ data.nestedTweenAnimationIsReversed : (bool?)null; // invert nested state only if Application.isPlaying, else reset to 'false'
                        nestedAnimation.SetState(nestedState, depth + 1);
                    }
                }
            }
        }



        internal const float minTimeScale = 0.01f;
        internal Sequence _sequence;
        #if UNITY_EDITOR
        [NonSerialized] bool _isStartValueBackedUp;
        internal static bool isPreviewing; // this should be a static field. For example, when GameObject has multiple TweenAnimations, if we're previewing one animation, other animations should not save start values and should be disabled in Inspector
        internal static (int id, int keyboardControl, TweenAnimation animation, string propertyPath, Data? iniData) _endValueHighlightData;

        internal static void ResetHighlightData() {
            if (_endValueHighlightData.keyboardControl == GUIUtility.keyboardControl) {
                GUIUtility.keyboardControl = 0; // reset the currently highlighted inspector property
            }
            if (_endValueHighlightData.iniData.HasValue && _endValueHighlightData.animation != null) {
                var iniData = _endValueHighlightData.iniData.Value;
                for (int i = 0; i < iniData.targets.Count; i++) {
                    // Debug.Log($"restore ini val after endValue preview {iniData.targets[i]?.name} {iniData.startValue}");
                    var tween = iniData.StartTweenOrLogError(_endValueHighlightData.animation, i);
                    if (tween.isAliveInternal) {
                        tween.elapsedTime = 0f;
                        tween.Stop();
                    }
                }
            }
            _endValueHighlightData = default;
        }
        #endif

        /// <summary>An animation is 'alive' when it has been played and has not stopped and has not completed yet. A paused animation is also considered 'alive'.</summary>
        public bool isAlive => _sequence.isAlive;

        /// <summary>Stops the animation.</summary>
        public void Stop() {
            // print("Stop");
            if (isAlive) { // a stopped animation keeps its _state, which tells where the animation left its targets
                // A simple animation stopped at the end is the same as a completed one, so its _state stays true. Its _state is already false if resetOnCompletion has moved the targets to the start
                bool isSimpleOrOverlapping = animationType == AnimationType.Simple || animationType == AnimationType.Overlapping;
                bool isAtEnd = animationType == AnimationType.Reversible ? _state : isSimpleOrOverlapping && _state && _sequence.progressTotal >= 1f; // unlike elapsedTimeTotal, progressTotal of a zero-duration sequence is 0 until it's updated
                if (Application.isPlaying && HasAdditiveTweens(_sequence)) {
                    // Additive tweens can't revert the delta of a stopped sequence, so Reset() and Trigger() assume that a stopped animation left the targets where its _state points.
                    bool isAtPlaybackEnd = isAtEnd ^ _sequence.root.tween.data.isSequenceInverted;
                    if (isAtPlaybackEnd ? _sequence.progressTotal < 1f : _sequence.elapsedTimeTotal > 0f && (_state || !isSimpleOrOverlapping)) {
                        Log(LogType.Error, additiveStopError);
                    }
                }
                _sequence.Stop();
                if (animationType != AnimationType.Reversible) {
                    SetState(isAtEnd);
                }
            }
        }

        /// <summary>Immediately completes the animation. See also <see cref="Tween.Complete"/>.</summary>
        public void Complete() {
            // print("Complete");
            if (isAlive && animationType == AnimationType.Infinite && cycleMode != Sequence.SequenceCycleMode.Restart && (_sequence.cyclesTotal == -1 ? _sequence.cyclesDone : _sequence.cyclesTotal - 1) % 2 != 0) {
                SetState(false); // an infinite animation completes its current cycle (or the last cycle set by SetRemainingCycles()), and a backward cycle ends at the start
            }
            _sequence.Complete();
        }

        const string _setRemainingCyclesNotSupportedWithReversible = "Reversible animations don't support " + nameof(SetRemainingCycles);
        const string _cantRevertAdditiveDelta = "Reset() and Trigger() can't revert the delta that additive tweens have applied.";
        internal const string additiveStopError = "An animation with additive tweens should only be stopped at the start or at the end, and a reversible animation only where its 'state' points. Otherwise, " + _cantRevertAdditiveDelta + " Use Reset() or Complete() instead, or pass 'TweenSettings.CancellationMode.Complete' to " + nameof(SetCancellationToken) + "().";
        internal const string additiveSetRemainingCyclesError = nameof(SetRemainingCycles) + "() is not supported while an animation with additive tweens is playing because it changes where the animation ends, so " + _cantRevertAdditiveDelta;
        internal const string additiveNestedStateError = "A nested reversible animation with additive tweens was played by itself, so its targets are not where the parent animation expects them. " + _cantRevertAdditiveDelta + " Play a nested animation with additive tweens only through its parent.";
        internal const string additiveOverlapResetError = "An overlapping animation with additive tweens can't be reset because Reset() can only revert the delta of the last play, while the previous plays have accumulated their deltas. The animation is stopped without reverting the deltas.";
        internal const string overlappingPauseError = "An overlapping animation can't be paused because the previous plays can no longer be controlled and continue playing until their end.";
        internal const string additiveInfiniteRestartError = "An infinite animation with additive tweens and 'cycleMode == Restart' can't be interrupted with 'InterruptionMode.Default' because it stops at the end of the cycle, so " + _cantRevertAdditiveDelta + " Use 'InterruptionMode.Reset' or another 'cycleMode' instead.";

        /// <summary>See also <see cref="Tween.SetRemainingCycles(int)"/>.</summary>
        public void SetRemainingCycles(int cycles) {
            if (animationType == AnimationType.Reversible) {
                Debug.LogError(_setRemainingCyclesNotSupportedWithReversible);
                return;
            }
            if (Application.isPlaying && isAlive && HasAdditiveTweens(_sequence)) {
                Log(LogType.Error, additiveSetRemainingCyclesError);
                return;
            }
            _sequence.SetRemainingCycles(cycles);
        }

        /// <summary>See also <see cref="Tween.SetRemainingCycles(bool)"/>.</summary>
        public void SetRemainingCycles(bool stopAtEndValue) {
            if (animationType == AnimationType.Reversible) {
                Debug.LogError(_setRemainingCyclesNotSupportedWithReversible);
                return;
            }
            if (Application.isPlaying && isAlive && HasAdditiveTweens(_sequence)) {
                Log(LogType.Error, additiveSetRemainingCyclesError);
                return;
            }
            _sequence.SetRemainingCycles(stopAtEndValue);
        }

        /// <summary>The number of completed cycles.</summary>
        public int cyclesDone => _sequence.cyclesDone;
        /// <summary>The total number of cycles. Returns -1 to indicate an infinite number of cycles.</summary>
        public int cyclesTotal => _sequence.cyclesTotal;

        [NonSerialized] bool _isPaused;
        /// <summary>Gets or sets whether the animation is paused.</summary>
        public bool isPaused {
            get => _isPaused;
            set {
                if (value && animationType == AnimationType.Overlapping) {
                    Log(LogType.Error, overlappingPauseError);
                    return;
                }
                SetPaused(value);
            }
        }

        // The Inspector pauses overlapping animations to scrub them, and unpauses them before triggering
        internal void SetPaused(bool value) {
            _isPaused = value;
            if (_sequence.isAlive) {
                _sequence.isPaused = value;
            }
        }

        /// <summary>Custom timeScale.</summary>
        public float timeScale { // p2 todo add Tween.TweenTimeScale(TweenAnimation)? Or Custom animation can be used instead?
            get => _timeScale;
            set {
                if (value < minTimeScale) {
                    Log(LogType.Error, $"{nameof(timeScale)} can't be less than {minTimeScale}.");
                    value = minTimeScale;
                }
                if (float.IsNaN(value) || float.IsInfinity(value)) {
                    throw new ArgumentException($"Invalid {nameof(timeScale)}: {value}.");
                }
                _timeScale = value;
                if (_sequence.isAlive) {
                    _sequence.timeScale = value;
                }
            }
        }

        /// <summary>The duration of one cycle.</summary>
        public float duration => _sequence.duration;
        /// <summary>The duration of all cycles. If the <see cref="cycles"/> == -1, returns <see cref="float.PositiveInfinity"/>.</summary>
        public float durationTotal => _sequence.durationTotal;
        /// <summary>Elapsed time of the current cycle.</summary>
        public float elapsedTime {
            get => _sequence.elapsedTime;
            set => _sequence.elapsedTime = value;
        }
        /// <summary>Elapsed time of all cycles.</summary>
        public float elapsedTimeTotal {
            get => _sequence.elapsedTimeTotal;
            set => _sequence.elapsedTimeTotal = value;
        }

        /// <summary>Normalized progress of the current cycle expressed in the 0..1 range.</summary>
        public float progress {
            get {
                if (!_sequence.root.ValidateIsAlive()) {
                    Debug.LogError(Constants.useProgressTotalInstead);
                    return 0f;
                }
                float res = _sequence.progress;
                return _sequence.root.tween.data.isSequenceInverted ? 1f - res : res;
            }
            set {
                if (!_sequence.root.ValidateIsAlive()) {
                    Debug.LogError(Constants.useProgressTotalInstead);
                    return;
                }
                if (_sequence.root.tween.data.isSequenceInverted) {
                    _sequence.progress = 1f - value;
                } else {
                    _sequence.progress = value;
                }
            }
        }

        /// <summary>Normalized progress of all cycles expressed in the 0..1 range. Can be accessed and set even if animation is not <see cref="isAlive"/>.</summary>
        public float progressTotal {
            get {
                if (!isAlive) {
                    return state ? 1f : 0f;
                }
                float totalProgress = _sequence.progressTotal;
                return _sequence.root.tween.data.isSequenceInverted ? 1f - totalProgress : totalProgress;
            }
            set => SetProgressTotal(value, true);
        }

        internal void SetProgressTotal(float value, bool autoStop) {
            if (!isAlive) {
                if (value >= 1f && state) {
                    return;
                }
                if (value <= 0f && !state) {
                    return;
                }
                // Not Trigger(), because the 'state' setter makes additive tweens of an overlapping animation accumulate, and setting the progress should be idempotent
                bool newState = !state;
                CreateSequenceAndApplyDirection(newState);
                SetState(newState);
            }
            _sequence.progressTotal = _sequence.root.tween.data.isSequenceInverted ? 1f - value : value;
            if (isAlive && (value >= 1f || value <= 0f)) {
                if (animationType == AnimationType.Reversible || animationType == AnimationType.Infinite) {
                    // _state of a simple animation stays true while it's alive, and Stop() sets it to whether the animation stopped at the end
                    SetState(animationType == AnimationType.Reversible && value >= 1f);
                }
                if (autoStop) {
                    Stop();
                }
            }
        }

        /// <summary>Use this method to wait for the animation in coroutines.</summary>
        public IEnumerator ToYieldInstruction() => _sequence.ToYieldInstruction();

        #if UNITASK_INSTALLED
        public static implicit operator Cysharp.Threading.Tasks.UniTask(TweenAnimation tweenAnimation) => tweenAnimation.ToUniTask();
        public async Cysharp.Threading.Tasks.UniTask ToUniTask() => await _sequence;
        #endif

        /// <inheritdoc cref="Tween.SetCancellationToken"/>
        public TweenAnimation SetCancellationToken(CancellationToken cancellationToken, TweenSettings.CancellationMode? cancellationMode = default) {
            _sequence.SetCancellationToken(cancellationToken, cancellationMode);
            return this;
        }

        #pragma warning disable CS0618 // Type or member is obsolete
        public Tween.TweenAwaiter GetAwaiter() => _sequence.GetAwaiter();
        #pragma warning restore CS0618

        /// <summary>Toggles animation state. Equivalent to calling 'animation.state = !animation.state'.</summary>
        public TweenAnimation ToggleState() {
            state = !state;
            return this;
        }

        /// <summary>Triggers the animation. The resulting animation state depends on the animation type (simple, reversible, or infinite). If the animation is already playing, applies <see cref="interruptionMode"/>.
        /// Simple and infinite animations: plays the animation from the beginning.<br/>
        /// Reversible animations: changes the direction.<br/></summary>
        public TweenAnimation Trigger() {
            if (!TryManipulate()) {
                return this;
            }
            if (isAlive) {
                if (ignoreDuplicateTrigger) {
                    print("ignoreDuplicateTrigger");
                } else {
                    if (animationType == AnimationType.Overlapping) {
                        // The abandoned sequence plays until its end, so its resetOnCompletion callback should not reset the _state of the new sequence
                        var abandonedRoot = _sequence.root.tween;
                        abandonedRoot.onComplete = null;
                        abandonedRoot.onCompleteCallback = null;
                        abandonedRoot.onCompleteTarget = null;
                        _sequence.isPaused = false; // isPaused can't reach the abandoned sequence later, so it would stay paused forever
                        _sequence = default;
                        SetState(false); // additive tweens of the new sequence start from zero delta
                        CreateSequenceAndApplyDirection(true);
                        SetState(true);
                    } else if (animationType == AnimationType.Simple && interruptionMode == InterruptionMode.Default) {
                        // Restore transform shake startValue
                        foreach (var data in animations) {
                            switch (data.tweenType) {
                                case TweenType.ShakeLocalPosition:
                                case TweenType.ShakeLocalRotation:
                                case TweenType.ShakeScale:
                                    foreach (var target in data.targets) {
                                        if (target is Transform shakeTransform) {
                                            if (PrimeTweenManager.Instance.shakes.TryGetValue((shakeTransform, data.tweenType), out (ValueWrapper startValue, int count) shakeStartValueData)) {
                                                ValueWrapper startValue = shakeStartValueData.startValue;
                                                switch (data.tweenType) {
                                                    case TweenType.ShakeLocalPosition: shakeTransform.localPosition = startValue.vector3; break;
                                                    case TweenType.ShakeLocalRotation: shakeTransform.localRotation = startValue.quaternion; break;
                                                    case TweenType.ShakeScale: shakeTransform.localScale = startValue.vector3; break;
                                                }
                                            }
                                        }
                                    }
                                    break;
                            }
                        }
                        // Rewind so additive tweens revert the delta they've applied so far
                        ResetAdditiveTweens(applyValues: true, _sequence.root.tween, false);
                        if (!isAlive) {
                            return this;
                        }
                        _sequence.Stop();
                        SetState(false);
                        CreateSequenceAndApplyDirection(true);
                        SetState(true);
                    } else {
                        Interrupt(!state);
                    }
                }
            } else {
                ToggleState();
            }
            return this;
        }

        internal Sequence CreateSequenceAndBackupStartValues(int depth = 0) {
            #if UNITY_EDITOR
            if (Application.isPlaying && !_isStartValueBackedUp && animations != null) {
                _isStartValueBackedUp = true;
                var backups = PrimeTweenManager._instance.startValuesBackup;
                foreach (Data data in animations) {
                    if (data.targets != null) {
                        foreach (var target in data.targets) {
                            if (target is Material material && UnityEditor.EditorUtility.IsPersistent(material)) {
                                Assert.IsTrue(Utils.IsMaterialAnimation(data.tweenType));
                                TryAddDataToBackup();
                                void TryAddDataToBackup() {
                                    foreach (var backup in backups) {
                                        if (backup.target == material) {
                                            return;
                                        }
                                    }
                                    // Debug.Log($"save {data.tweenType} {target.name}", target);
                                    backups.Add(new PrimeTweenManager.StartValueBackupData { target = material, startValue = data.startValue, tweenType = data.tweenType, propertyName = data.stringParam });
                                }
                            }
                        }
                    }
                }
            }
            if (!Application.isPlaying && animations != null && _iniValues == null) {
                _iniValues = new ValueWrapper?[animations.Count][];
                for (int i = 0; i < animations.Count; i++) {
                    var data = animations[i];
                    var targets = data.targets;
                    if (targets != null) {
                        var iniValues = new ValueWrapper?[targets.Count];
                        for (int targetIndex = 0; targetIndex < targets.Count; targetIndex++) {
                            iniValues[targetIndex] = GetCurrentValue(data.operation, targets[targetIndex], data.tweenType, data.stringParam, data.materialIndex);
                            // print($"{(context != null ? context.name : string.Empty)} save ini val {targets[targetIndex]?.name} {iniValues[targetIndex]} {data.tweenType}", targets[targetIndex] ?? context);
                        }
                        _iniValues[i] = iniValues;
                    }
                }
            }
            #endif

            return CreateSequence(depth);
        }

        internal void CreateSequenceAndApplyDirection(bool newState) {
            // print($"CreateSequenceAndApplyDirection {newState}");
            Assert.IsTrue(CanManipulate());
            Assert.IsFalse(isAlive);

            #if UNITY_EDITOR
            isPreviewing = true;
            ResetHighlightData();
            PrimeTweenManager.Instance.TryAddCurrentTweenAnimation(this);
            #endif

            _sequence = CreateSequenceAndBackupStartValues();
            if (!isAlive) {
                return;
            }

            bool isBackward = animationType == AnimationType.Reversible && !newState;
            // print($"ApplyDirection isBackward {isBackward}");
            TweenData.ResetSequence(_sequence.root.tween, isBackward);
            if (!isAlive) {
                return; // a callback invoked by the reset stopped the animation
            }
            if (isBackward) {
                TweenData.InvertSequence(_sequence);
            } else if (resetOnCompletion && CanResetOnComplete()) {
                _sequence.root.ResetOnCompletion();
            }

            if (resetOnCompletion && CanResetOnComplete()) {
                _sequence.OnComplete(this, x => x.SetState(false), warnIfTargetDestroyed: false);
            }
        }

        static bool HasAdditiveTweens(Sequence sequence) {
            foreach (var child in sequence.GetAllChildren()) {
                if (child.data.isAdditive) {
                    return true;
                }
            }
            return false;
        }

        static void ResetAdditiveTweens(bool applyValues, ColdData seq, bool toEnd) {
            bool isResetToEnd = TweenData.IsResetToEnd(ref seq.data, toEnd);
            foreach (var child in new Sequence(seq).GetSelfChildren(isForward: isResetToEnd)) {
                ref var d = ref child.data;
                if (d.IsSequenceRoot()) {
                    ResetAdditiveTweens(applyValues, child, isResetToEnd);
                    if (!seq.data.isAlive) {
                        return;
                    }
                } else if (d.isAdditive) {
                    d.cyclesDone = isResetToEnd ? d.cyclesTotal : TweenData.iniCyclesDone; // the eased t depends on cyclesDone, for example, with Yoyo or Incremental cycles
                    if (applyValues) {
                        d.SetState(State.None);
                        child.managedData.UpdateAndSetElapsedTimeTotal(isResetToEnd ? float.MaxValue : TweenData.negativeElapsedTime, out _, false, ref d);
                        if (!seq.data.isAlive) {
                            return; // a setter exception or a destroyed target has stopped the entire sequence
                        }
                    } else {
                        var payload = child.blob.Load<Tween.AdditivePayload>();
                        payload.prevT = child.managedData.CalcEasedT(isResetToEnd ? 1f : 0f, false, ref d);
                        child.blob.Store(payload);
                    }
                }
            }
        }

        internal bool CanManipulate() {
            if (_sequence.isAlive && !_sequence.root.tween.data.canManipulate()) {
                return false;
            }
            return true;
        }

        bool TryManipulate() {
            if (!CanManipulate()) {
                Log(LogType.Error, Constants.cantManipulateNested);
                return false;
            }
            return true;
        }

        internal static bool SanitiseCycles(AnimationType type, ref int cycles) {
            bool isReversible = type == AnimationType.Reversible;
            if (isReversible || type == AnimationType.Overlapping) {
                if (cycles < 1) {
                    cycles = 1;
                    return true;
                }
                if (isReversible && cycles % 2 == 0) {
                    cycles--;
                    return true;
                }
            } else if (cycles < -1) {
                cycles = -1;
                return true;
            }
            return false;
        }

        internal static bool SanitiseCycleMode(AnimationType type, ref Sequence.SequenceCycleMode cycleMode) {
            if (type == AnimationType.Reversible && cycleMode == Sequence.SequenceCycleMode.Restart) {
                cycleMode = Sequence.SequenceCycleMode.YoyoChildren;
                return true;
            }
            return false;
        }

        internal static bool SanitiseInterruptionMode(AnimationType type, ref InterruptionMode mode) {
            if (type == AnimationType.Infinite) {
                if (mode == InterruptionMode.Complete) {
                    mode = InterruptionMode.Reset;
                    return true;
                }
            } else if (type == AnimationType.Reversible) {
                if (mode == InterruptionMode.Reset) {
                    mode = InterruptionMode.Complete;
                    return true;
                }
            }
            return false;
        }

        Sequence CreateSequence(int depth = 0) {
            if (depth > 32) {
                Debug.LogError(TweenAnimationComponent.selfReferenceError);
                return default;
            }
            var anims = animations;
            if (anims == null) {
                Log(LogType.Error, $"'{nameof(anims)}' is null.");
                return default;
            }

            SanitiseCycles(animationType, ref cycles);
            SanitiseCycleMode(animationType, ref cycleMode);
            var seq = Sequence.Create(cycles, cycleMode, sequenceEase, useUnscaledTime, updateType);
            if (!seq.isAlive) {
                return seq;
            }
            Assert.AreEqual(PrimeTweenManager.dummyTarget, seq.root.tween.managedData.target);
            seq.root.tween.managedData.target = this;
            Assert.IsNull(seq.root.tween.customOnValueChange);
            seq.root.tween.customOnValueChange = context;
            seq.timeScale = Mathf.Max(minTimeScale, _timeScale);
            seq.isPaused = _isPaused;
            for (int i = 0; i < anims.Count; i++) {
                Data data = anims[i];
                if (data.operation == Operation.Disabled || data.tweenType == TweenType.Disabled) {
                    continue;
                }

                void AddSequence(Sequence otherSequence) {
                    #if UNITY_EDITOR
                    otherSequence.root.tween.indexInTweenAnimation = i;
                    #endif
                    switch (data.operation) {
                        case Operation.Insert:
                            seq.Insert(data.startTime, otherSequence);
                            break;
                        case Operation.Chain:
                            seq.Chain(otherSequence);
                            break;
                        case Operation.Group:
                            seq.Group(otherSequence);
                            break;
                        default:
                            LogError($"Invalid {nameof(Operation)}: {data.operation}.");
                            break;
                    }
                }
                if (data.tweenType == TweenType.TweenAnimationComponent) {
                    string error = string.Empty;
                    if (!data.GetUnityTarget(out TweenAnimationComponent target, ref error, 0)) {
                        LogError(error);
                        continue;
                    }
                    var otherAnimation = target.animation;
                    if (otherAnimation == null) {
                        LogError("Target's TweenAnimationComponent animation is null.");
                        continue;
                    }
                    if (target == context || otherAnimation == this) {
                        LogError(TweenAnimationComponent.selfReferenceError);
                        continue;
                    }
                    if (otherAnimation.animationType == AnimationType.Infinite) {
                        LogError(Constants.infiniteTweenInSequenceError);
                        continue;
                    }
                    if (otherAnimation.isAlive) {
                        otherAnimation.Reset(); // we should reset the nested animation so that it doesn't overwrite the newly created parent animation
                    }
                    var nestedSequence = otherAnimation.CreateSequenceAndBackupStartValues(depth + 1);
                    if (!nestedSequence.isAlive) {
                        LogError(null);
                        continue;
                    }
                    if (data.nestedTweenAnimationIsReversed) {
                        if (otherAnimation.animationType != AnimationType.Reversible) {
                            LogError(Constants.nestedAnimationShouldBeReversible);
                        }
                        TweenData.InvertSequence(nestedSequence);
                    }
                    // Additive tweens of the nested sequence are synced to where the parent's _state assumes them, so a nested animation played by itself leaves a delta that nobody reverts.
                    // A reversed nested animation with _state == false is skipped: it can be unplayed, and the reversed nesting treats its start values as its end
                    if (Application.isPlaying
                        && (depth == 0 || animationType == AnimationType.Reversible)
                        && otherAnimation.animationType == AnimationType.Reversible
                        && otherAnimation._state != (_state ^ data.nestedTweenAnimationIsReversed)
                        && (otherAnimation._state || !data.nestedTweenAnimationIsReversed)
                        && HasAdditiveTweens(nestedSequence)) {
                        Log(LogType.Error, additiveNestedStateError, target);
                    }
                    AddSequence(nestedSequence);
                } else if (data.tweenType == TweenType.ShakeCamera) {
                    string error = string.Empty;
                    if (!data.GetUnityTarget(out Camera target, ref error, 0)) {
                        LogError(error);
                        continue;
                    }
                    AddSequence(Tween.ShakeCamera(target, data.shakeCameraStrengthFactor, data.duration, data.shakeFrequency));
                } else {
                    int count = Math.Max(1, data.targets?.Count ?? 0);
                    for (int targetIndex = 0; targetIndex < count; targetIndex++) {
                        string error = string.Empty;
                        Tween tween = data.StartTween(ref error, this, targetIndex);
                        if (!tween.isAliveInternal) {
                            LogError(error);
                            continue;
                        }
                        #if UNITY_EDITOR
                        tween.tween.indexInTweenAnimation = i;
                        #endif
                        if (targetIndex == 0) {
                            switch (data.operation) {
                                case Operation.Insert:
                                    seq.Insert(data.startTime, tween);
                                    break;
                                case Operation.Chain:
                                    seq.Chain(tween);
                                    break;
                                case Operation.Group:
                                    seq.Group(tween);
                                    break;
                                default:
                                    LogError($"Invalid {nameof(Operation)}: {data.operation}.");
                                    continue;
                            }
                        } else {
                            // Tweens on the first target should adhere to the actual operation, while all later tweens should be grouped to the first one
                            seq.Group(tween);
                        }
                    }
                }

                void LogError(string msg) {
                    if (!string.IsNullOrEmpty(msg)) {
                        Log(LogType.Error, $"{nameof(TweenAnimation)} is not set up correctly at index {i}. {msg}");
                    }
                }
            }
            // Nested sequences are synced by the top-level call: the parent's _state decides where their additive tweens are
            if (depth == 0) {
                ResetAdditiveTweens(applyValues: false, seq.root.tween, _state);
            }
            return seq;
        }

        void Log(LogType type, string msg, UnityEngine.Object logContext = null) {
            object log = $"{(context != null ? context.name : string.Empty)} {msg}";
            Debug.unityLogger.Log(type, log, logContext ?? context);
        }

        internal bool CanResetOnComplete() => cycles >= 1 && (cycleMode == Sequence.SequenceCycleMode.Restart || cycles % 2 != 0) && animationType != AnimationType.Reversible;

        /// <summary>Defines how an animation is added to a sequence.</summary>
        /// <seealso cref="Sequence.Chain(Tween)"/> <seealso cref="Sequence.Group(Tween)"/> <seealso cref="Sequence.Insert(float, Tween)"/>
        public enum Operation : sbyte { Disabled = -1, Chain, Group, Insert }

        /// <summary>Controls how <see cref="TweenAnimation"/> behaves when interrupted.</summary>
        /// <seealso cref="state"/> <seealso cref="TweenAnimation.interruptionMode"/>
        public enum InterruptionMode : byte {
            [Tooltip("Simple animations: restart the animation from the beginning.\n\n" +
                     "Reversible animations: seamlessly change the direction.\n\n" +
                     "Infinite animations: continue playing the current loop until its end. Use this mode to prevent abrupt changes and smoothly stop infinite animations.")]
            Default,
            [Tooltip("Completes the animation.")]
            Complete,
            [Tooltip("Instantly resets the animation to the beginning.")]
            Reset
        }

        internal void PlayIfNotAlive() {
            if (!isAlive) {
                Trigger();
            }
        }

        /// <summary>Instantly resets the animation to the beginning.</summary>
        public void Reset() {
            if (!TryManipulate()) {
                return;
            }
            // print("Reset");
            if (Application.isPlaying) {
                if (!isAlive) {
                    if (animations == null) {
                        Log(LogType.Error, $"'{nameof(animations)}' is null.");
                        return;
                    }
                    _sequence = CreateSequence();
                }
                if (isAlive) {
                    if (_state && animationType == AnimationType.Overlapping && HasAdditiveTweens(_sequence)) {
                        Log(LogType.Error, additiveOverlapResetError);
                        // Callers like the parent animation and OnDisable() rely on Reset() to stop the animation
                        _sequence.Stop();
                        return;
                    }
                    // 'toEnd' is relative to the playback direction, and the sequence of a reversible animation playing backward is inverted
                    TweenData.ResetSequence(_sequence.root.tween, _sequence.root.tween.data.isSequenceInverted);
                }
                SetState(false);
            }
            #if UNITY_EDITOR
            else {
                if (PrimeTweenManager.HasInstance) {
                    // Stop the sequences abandoned by an overlapping animation so they don't change the restored initial values
                    PrimeTweenManager.ProcessAll(this, tween => {
                        if (tween.data.IsMainSequenceRoot()) {
                            new Sequence(tween.sequence).Stop();
                        }
                        return true;
                    }, true);
                }
                SetState(null);
                isPreviewing = false;
                ResetHighlightData();
                isPaused = false;
                ResetComponentsInEditor(0);
            }
            #endif
            _sequence.Stop();
        }

        #if UNITY_EDITOR
        void ResetComponentsInEditor(int depth) {
            if (depth > 32) {
                Debug.LogError(TweenAnimationComponent.selfReferenceError);
                return;
            }
            if (animations != null) {
                // restore ini values
                if (_iniValues != null) { // can be null if scrubbed to the beginning manually, then deselected
                    for (int i = 0; i < animations.Count; i++) {
                        var data = animations[i];
                        if (_iniValues.Length == animations.Count) {
                            var iniValues = _iniValues[i];
                            if (iniValues != null) {
                                if (Data.AdditiveToAbsoluteTweenType(data.tweenType) is TweenType absoluteTweenType) {
                                    data.tweenType = absoluteTweenType;
                                }
                                for (int targetIndex = 0; targetIndex < data.targets.Count && targetIndex < iniValues.Length; targetIndex++) {
                                    if (iniValues[targetIndex] is ValueWrapper iniVal) {
                                        // A constant tween ends at the initial value regardless of cycles, cycleMode, and ease. For example, an even number of Yoyo cycles ends at the startValue
                                        data.startValue = iniVal;
                                        data.endValue = iniVal;
                                        data.StartTweenOrLogError(this, targetIndex).Complete();

                                        // var target = data.targets[targetIndex];
                                        // print($"{i}/{animations.Count} restore ini val {(target != null ? target.name : "NULL_OR_DESTROYED")} {iniVal} {data.tweenType}", target);
                                    }
                                }
                            }
                        } else {
                            Log(LogType.Error, $"Invalid number of _iniValues: {_iniValues.Length} != {animations.Count}");
                        }
                    }
                    _iniValues = null;
                }

                foreach (var data in animations) {
                    if (data.targets != null) {
                        foreach (var target in data.targets) {
                            if (target is Renderer renderer && renderer) {
                                // Debug.Log($"reset PropertyBlock {renderer.name}", renderer);
                                renderer.SetPropertyBlock(null);
                                int materialIndex = data.materialIndex;
                                if (materialIndex >= 0 && materialIndex < renderer.sharedMaterials.Length) {
                                    renderer.SetPropertyBlock(null, materialIndex);
                                }
                            }
                            #if TEXT_MESH_PRO_INSTALLED
                            else if (target is TMP_Text text && text) {
                                // Debug.Log($"reset maxVisibleCharacters {text.name}", text);
                                text.maxVisibleCharacters = 99999;
                            }
                            #endif
                            else if ((target as TweenAnimationComponent)?.animation is TweenAnimation nested) {
                                if (this == nested) {
                                    Debug.LogError(TweenAnimationComponent.selfReferenceError, target);
                                } else {
                                    nested.ResetComponentsInEditor(depth + 1);
                                }
                            }
                        }
                    }
                }
            }
        }
        #endif

        void ISerializationCallbackReceiver.OnBeforeSerialize() {}
        void ISerializationCallbackReceiver.OnAfterDeserialize() {
            if (animations != null) {
                for (var i = 0; i < animations.Count; i++) {
                    Data data = animations[i];
                    if (data.customData is Data.Custom customData) {
                        var tweenType = data.tweenType;
                        if (tweenType != TweenType.CustomFloat) {
                            customData.unityEventFloat = null;
                        }
                        if (tweenType != TweenType.CustomColor) {
                            customData.unityEventColor = null;
                        }
                        if (tweenType != TweenType.CustomVector2) {
                            customData.unityEventVector2 = null;
                        }
                        if (tweenType != TweenType.CustomVector3 && tweenType != TweenType.ShakeCustom) {
                            customData.unityEventVector3 = null;
                        }
                        if (tweenType != TweenType.CustomVector4) {
                            customData.unityEventVector4 = null;
                        }
                        if (tweenType != TweenType.CustomRect) {
                            customData.unityEventRect = null;
                        }
                        if (tweenType != TweenType.Callback) {
                            customData.callback = null;
                        }
                        data.customData = customData;
                        animations[i] = data;
                    }
                }
            }
        }

        internal static ValueWrapper? GetCurrentValue(Operation operation, [CanBeNull] UnityEngine.Object target, TweenType tweenType, string stringParam, int materialIndex) {
            if (operation == Operation.Disabled) {
                return null;
            }
            if (Data.IsCustomTweenType(tweenType)
                || tweenType == TweenType.Disabled
                || Utils.IsShake(tweenType)
                || tweenType == TweenType.TweenAnimationComponent
               ) {
                return null;
            }
            if (Data.AdditiveToAbsoluteTweenType(tweenType) is TweenType absoluteTweenType) {
                tweenType = absoluteTweenType;
            }
            Type targetType;
            try {
                targetType = Utils.TweenTypeToTweenData(tweenType).Item2;
            } catch {
                return null;
            }
            if (tweenType != TweenType.GlobalTimeScale) {
                if (target == null || targetType == null || !targetType.IsAssignableFrom(target.GetType())) {
                    return null;
                }
            }

            TweenType? remapped = RemapToQuaternionType(tweenType);
            TweenType? RemapToQuaternionType(TweenType t) {
                switch (t) {
                    case TweenType.Rotation: return TweenType.RotationQuaternion;
                    case TweenType.LocalRotation: return TweenType.LocalRotationQuaternion;
                    case TweenType.RigidbodyMoveRotation: return TweenType.RigidbodyMoveRotationQuaternion;
                    default: return null;
                }
            }

            var blob = new ColdData.Blob();
            if (remapped.HasValue) {
                return Utils.GetAnimatedValue(target, remapped.Value, ref blob).quaternion.eulerAngles.ToContainer();
            }
            if (tweenType == TweenType.ScaleUniform) {
                return Utils.GetAnimatedValue(target, TweenType.ScaleX, ref blob);
            }
            int propId = Shader.PropertyToID(stringParam);
            if (((targetType == typeof(Material) && target is Material) || (targetType == typeof(Renderer) && target is Renderer))
                && Utils.IsMaterialPropertyAnimation(tweenType)
                && !Utils.IsValidMaterialProperty(tweenType, target, propId, materialIndex)
               ) {
                return null;
            }
            blob.Store(new MaterialPayload {
                propId = propId,
                #if PRIME_TWEEN_PRO && UNITY_2021_1_OR_NEWER
                stPropId = tweenType == TweenType.MaterialPropertyBlockTextureScale || tweenType == TweenType.MaterialPropertyBlockTextureOffset ? Tween.GetMaterialSTPropId(propId, stringParam) : 0,
                #endif
                materialIndex = materialIndex
            });
            return Utils.GetAnimatedValue(target, tweenType, ref blob);
        }

        /// <summary>Internal animation data. Typically, it should not be modified directly. Use only for advanced use cases.</summary>
        [Serializable, EditorBrowsable(EditorBrowsableState.Advanced)]
        public struct Data {
            [SerializeField] public Operation operation;
            [SerializeField] public float startTime;
            [SerializeField] public TweenType tweenType;
            [SerializeField] public List<UnityEngine.Object> targets;
            [SerializeField] internal int intParam; // materialIndex + 1, so the default 0 applies the MaterialPropertyBlock to the whole Renderer
            [SerializeField] public string stringParam; // stores the name of the Material property to animate
            [SerializeField] internal Custom[] _customData;
            [SerializeField] internal bool boolParam; // hasStartValue / callbackWarnIfTargetDestroyed / shakeEnableFalloff
            [SerializeField, Tooltip("Controls in which playback direction the callback is invoked.")] public CallbackDirection callbackDirectionMode;
            [SerializeField, Tooltip("Start value of an animation. Enable to set the start value manually.\n\n" +
                                     "Disable to use the current value (only works in Edit Mode).")]
            public ValueWrapper startValue;                                                         // Or 'xyz': shakeCustomStartValue | 'w': shakeFrequency
            [SerializeField, Tooltip("End value of an animation")] public ValueWrapper endValue;    // Or 'x': shakeCameraStrengthFactor / 'xyz': shakeStrength | 'w': shakeAsymmetry / 'xyz': additive deltaValue
            [SerializeField] public float duration;
            [SerializeField, Tooltip(Constants.easeTooltip)] public Ease ease; // Or ShakeSettings.falloffEase
            [SerializeField] public AnimationCurve customEase;
            [SerializeField, Tooltip(Constants.cyclesTooltip)] public int cycles; // p1 todo allow having multiple cycles for TweenAnimationComponent?
            [SerializeField, Tooltip(Constants.cycleModeTooltip)] public CycleMode cycleMode;



            internal Data(Data other) {
                this = other;
            }

            [Serializable]
            public struct Custom {
                [SerializeField] public UnityEvent callback;
                [SerializeField] public UnityEventFloat unityEventFloat;
                [SerializeField] public UnityEventColor unityEventColor;
                [SerializeField] public UnityEventVector2 unityEventVector2;
                [SerializeField] public UnityEventVector3 unityEventVector3;
                [SerializeField] public UnityEventVector4 unityEventVector4;
                [SerializeField] public UnityEventRect unityEventRect;



                [Serializable] public class UnityEventFloat : UnityEvent<float> {}
                [Serializable] public class UnityEventColor : UnityEvent<Color> {}
                [Serializable] public class UnityEventVector2 : UnityEvent<Vector2> {}
                [Serializable] public class UnityEventVector3 : UnityEvent<Vector3> {}
                [Serializable] public class UnityEventVector4 : UnityEvent<Vector4> {}
                [Serializable] public class UnityEventRect : UnityEvent<Rect> {}
            }

            public Custom? customData {
                get => _customData != null && _customData.Length == 1 ? _customData[0] : (Custom?)null;
                set {
                    if (value.HasValue) {
                        if (_customData != null && _customData.Length == 1) {
                            _customData[0] = value.Value;
                        } else {
                            _customData = new []{value.Value};
                        }
                    } else {
                        _customData = null;
                    }
                }
            }

            public bool hasStartValue { get => boolParam; set => boolParam = value; }
            public bool callbackWarnIfTargetDestroyed { get => boolParam; set => boolParam = value; }
            public bool shakeEnableFalloff { get => boolParam; set => boolParam = value; }
            public bool nestedTweenAnimationIsReversed { get => boolParam; set => boolParam = value; }

            /// <summary>The index of the material in Renderer.sharedMaterials animated by MaterialPropertyBlock animations. -1 animates all materials of the Renderer.</summary>
            public int materialIndex { get => intParam - 1; set => intParam = value + 1; }

            public Vector3 shakeCustomStartValue { get => startValue.vector3; set => startValue.vector3 = value; }
            public float shakeFrequency { get => startValue.w; set => startValue.w = value; }

            public float shakeCameraStrengthFactor { get => endValue.x; set => endValue.x = value; }
            public Vector3 shakeStrength { get => endValue.vector3; set => endValue.vector3 = value; }
            public float shakeAsymmetry { get => endValue.w; set => endValue.w = value; }

            TweenSettings<int> settingsInt => CreateSettings(Mathf.RoundToInt(startValue.single), Mathf.RoundToInt(endValue.single));
            TweenSettings<float> settingsFloat => CreateSettings(startValue.single, endValue.single);
            TweenSettings<Color> settingsColor => CreateSettings(startValue.color, endValue.color);
            TweenSettings<Vector2> settingsVector2 => CreateSettings(startValue.vector2, endValue.vector2);
            TweenSettings<Vector3> settingsVector3 => CreateSettings(startValue.vector3, endValue.vector3);
            TweenSettings<Vector4> settingsVector4 => CreateSettings(startValue.vector4, endValue.vector4);
            TweenSettings<Quaternion> settingsQuaternion => CreateSettings(startValue.quaternion, endValue.quaternion);
            TweenSettings<Rect> settingsRect => CreateSettings(startValue.rect, endValue.rect);
            TweenSettings<T> CreateSettings<T>(T start, T end) where T : struct {
                if (cycles < 0) {
                    Debug.LogError(Constants.infiniteTweenInSequenceError);
                    cycles = 1;
                }
                TweenSettings settings = new TweenSettings(duration, ease, ease == Ease.Custom ? customEase : (Easing?)null, cycles, cycleMode);
                return new TweenSettings<T>(start, end, settings);
            }

            internal static bool IsCustomTweenType(TweenType type) {
                switch (type) {
                    case TweenType.CustomFloat:
                    case TweenType.CustomColor:
                    case TweenType.CustomVector2:
                    case TweenType.CustomVector3:
                    case TweenType.CustomVector4:
                    case TweenType.CustomQuaternion:
                    case TweenType.CustomRect:
                        return true;
                    default: return false;
                }
            }

            internal static TweenType? AdditiveToAbsoluteTweenType(TweenType type) {
                switch (type) {
                    case TweenType.PositionAdditive: return TweenType.Position;
                    case TweenType.LocalPositionAdditive: return TweenType.LocalPosition;
                    case TweenType.ScaleAdditive: return TweenType.Scale;
                    case TweenType.RotationAdditive: return TweenType.Rotation;
                    case TweenType.LocalRotationAdditive: return TweenType.LocalRotation;
                    default: return null;
                }
            }

            internal bool GetUnityTarget<T>(out T tweenTarget, ref string error, int targetIndex) where T : UnityEngine.Object {
                var target = targets[targetIndex];
                if (target == null) {
                    tweenTarget = null;
                    if (Application.isPlaying && !PrimeTweenManager.HasPrefabStage()) {
                        error = $"'target' ({typeof(T)}) is null or destroyed.";
                    }
                    return false;
                }

                tweenTarget = target as T;
                if (tweenTarget == null) {
                    error = $"'target' type mismatch: expected ({typeof(T)}), but was {target.GetType()}.";
                    return false;
                }
                return true;
            }

            internal bool GetCustomData(out Custom result, ref string error) {
                Custom? data = customData;
                if (!data.HasValue) {
                    error = $"'{nameof(customData)}' is null or empty.";
                    result = default;
                    return false;
                }
                result = data.Value;
                return true;
            }

            bool CheckEvent(UnityEventBase evt, ref string error, TweenAnimation context) {
                int eventCount = evt.GetPersistentEventCount();
                if (eventCount != 0) { // return true if there are no persistent events as there can be dynamic C# events added via AddListener()
                    for (int i = 0; i < eventCount; i++) {
                        var persistentTarget = evt.GetPersistentTarget(i);
                        if (persistentTarget == null) {
                            error = $"UnityEvent target is null or destroyed at index {i}.";
                            return false;
                        }
                        if (persistentTarget is TweenAnimationComponent animationComponent && animationComponent.animation == context) {
                            error = TweenAnimationComponent.selfReferenceError;
                            return false;
                        }
                        if (string.IsNullOrEmpty(evt.GetPersistentMethodName(i))) {
                            error = $"UnityEvent method name is invalid at index {i}.";
                            return false;
                        }
                    }
                }
                return true;
            }

            bool GetPropName([CanBeNull] out string propName, ref string err) {
                if (string.IsNullOrEmpty(stringParam)) {
                    err = "Material property name is empty.";
                    propName = null;
                    return false;
                }
                propName = stringParam;
                return true;
            }

            bool GetPropId(out int propId, ref string err, int targetIndex) {
                if (!GetPropName(out string propName, ref err)) {
                    propId = -1;
                    return false;
                }

                propId = Shader.PropertyToID(propName);
                var target = targets[targetIndex];
                if (target is Material material && !Utils.IsValidMaterialProperty(tweenType, target, propId, materialIndex)) {
                    Debug.LogWarning($"Material doesn't have a property with id '{propId}', propName: '{propName}'.", material);
                }
                if (target is Renderer renderer && !Utils.IsValidMaterialProperty(tweenType, target, propId, materialIndex)) {
                    Debug.LogWarning($"Renderer's material doesn't have a property with id '{propId}', propName: '{propName}', materialIndex: {materialIndex}.", renderer);
                }
                return true;
            }

            ShakeSettings GetShakeSettings() {
                Ease? falloff = shakeEnableFalloff ? ease : (Ease?)null;
                const AnimationCurve strengthOverTime = null;
                return new ShakeSettings(shakeStrength, duration, shakeFrequency, falloff, strengthOverTime, Ease.OutQuad, shakeAsymmetry, 1, 0f, 0f, false, UpdateType.Default);
            }

            internal Tween StartTweenOrLogError(TweenAnimation ctx, int i) {
                string error = string.Empty;
                var res = StartTween(ref error, ctx, i);
                if (res.isAliveInternal) {
                    return res;
                } else if (!string.IsNullOrEmpty(error)) {
                    Debug.LogError(error);
                }
                return default;
            }

            internal Tween StartTween(ref string err, TweenAnimation ctx, int i) {
                switch (tweenType) {
                    case TweenType.Disabled:
                    case TweenType.TweenAnimationComponent:
                    case TweenType.ShakeCamera:
                        // Handled by TweenAnimation
                        err = $"Invalid TweenType: {tweenType}";
                        return default;
                    case TweenType.MainSequence:
                    case TweenType.NestedSequence:
                    case TweenType.TweenTimeScale:
                    case TweenType.TweenTimeScaleSequence:
                    case TweenType.VisualElementLayout:
                    case TweenType.VisualElementPosition:
                    case TweenType.VisualElementRotationQuaternion:
                    case TweenType.VisualElementScale:
                    case TweenType.VisualElementSize:
                    case TweenType.VisualElementTopLeft:
                    case TweenType.VisualElementColor:
                    case TweenType.VisualElementBackgroundColor:
                    case TweenType.VisualElementOpacity:
                    #if PRIME_TWEEN_EXPERIMENTAL
                    case TweenType.CustomDouble:
                    #endif
                        err = $"Unsupported TweenType: {tweenType}.";
                        return default;

                    case TweenType.Delay: return Tween.Delay(duration);

                    case TweenType.ShakeLocalPosition: { return GetUnityTarget(out Transform t, ref err, i) ? Tween.ShakeLocalPosition(t, GetShakeSettings()) : default; }
                    case TweenType.ShakeLocalRotation: { return GetUnityTarget(out Transform t, ref err, i) ? Tween.ShakeLocalRotation(t, GetShakeSettings()) : default; }
                    case TweenType.ShakeScale:         { return GetUnityTarget(out Transform t, ref err, i) ? Tween.ShakeScale        (t, GetShakeSettings()) : default; }

                    case TweenType.ShakeCustom:        { return GetCustomData(out var custom, ref err) && custom.unityEventVector3 is Custom.UnityEventVector3 t && CheckEvent(t, ref err, ctx) ? Tween.ShakeCustom(t, shakeCustomStartValue, GetShakeSettings(), (x, val) => x.Invoke(val)) : default; }

                    case TweenType.CustomFloat:        { return GetCustomData(out var custom, ref err) && custom.unityEventFloat   is Custom.UnityEventFloat   t && CheckEvent(t, ref err, ctx) ? Tween.Custom(t, settingsFloat,      (x, val) => x.Invoke(val)) : default; }
                    case TweenType.CustomColor:        { return GetCustomData(out var custom, ref err) && custom.unityEventColor   is Custom.UnityEventColor   t && CheckEvent(t, ref err, ctx) ? Tween.Custom(t, settingsColor,      (x, val) => x.Invoke(val)) : default; }
                    case TweenType.CustomVector2:      { return GetCustomData(out var custom, ref err) && custom.unityEventVector2 is Custom.UnityEventVector2 t && CheckEvent(t, ref err, ctx) ? Tween.Custom(t, settingsVector2,    (x, val) => x.Invoke(val)) : default; }
                    case TweenType.CustomVector3:      { return GetCustomData(out var custom, ref err) && custom.unityEventVector3 is Custom.UnityEventVector3 t && CheckEvent(t, ref err, ctx) ? Tween.Custom(t, settingsVector3,    (x, val) => x.Invoke(val)) : default; }
                    case TweenType.CustomVector4:      { return GetCustomData(out var custom, ref err) && custom.unityEventVector4 is Custom.UnityEventVector4 t && CheckEvent(t, ref err, ctx) ? Tween.Custom(t, settingsVector4,    (x, val) => x.Invoke(val)) : default; }
                    case TweenType.CustomRect:         { return GetCustomData(out var custom, ref err) && custom.unityEventRect    is Custom.UnityEventRect    t && CheckEvent(t, ref err, ctx) ? Tween.Custom(t, settingsRect,       (x, val) => x.Invoke(val)) : default; }

                    case TweenType.Callback:           { return GetCustomData(out var custom, ref err) && custom.callback          is UnityEvent               t && CheckEvent(t, ref err, ctx) ? Utils.SetCallbackDirectionMode(Sequence.CreateCallback(t, x => x.Invoke(), callbackWarnIfTargetDestroyed), callbackDirectionMode) ?? default : default; }

                    // Comment out this check because IsValidMaterialProperty is not 100% reliable. For example, when a material has a Vector with an unmodified value, the HasVector() will fail.
                    /*if (!Utils.IsValidMaterialProperty(tweenType, tweenTarget, propId)) {
                        err = $"Material doesn't have the '{stringParam}' property.";
                        return default;
                    }*/
                    case TweenType.MaterialColorProperty:   { return GetUnityTarget(out Material m, ref err, i) && GetPropId(out int propId, ref err, i) ? Tween.MaterialColor        (m, propId, settingsColor)   : default; }
                    case TweenType.MaterialProperty:        { return GetUnityTarget(out Material m, ref err, i) && GetPropId(out int propId, ref err, i) ? Tween.MaterialProperty     (m, propId, settingsFloat)   : default; }
                    case TweenType.MaterialAlphaProperty:   { return GetUnityTarget(out Material m, ref err, i) && GetPropId(out int propId, ref err, i) ? Tween.MaterialAlpha        (m, propId, settingsFloat)   : default; }
                    case TweenType.MaterialTextureOffset:   { return GetUnityTarget(out Material m, ref err, i) && GetPropId(out int propId, ref err, i) ? Tween.MaterialTextureOffset(m, propId, settingsVector2) : default; }
                    case TweenType.MaterialTextureScale:    { return GetUnityTarget(out Material m, ref err, i) && GetPropId(out int propId, ref err, i) ? Tween.MaterialTextureScale (m, propId, settingsVector2) : default; }
                    case TweenType.MaterialPropertyVector4: { return GetUnityTarget(out Material m, ref err, i) && GetPropId(out int propId, ref err, i) ? Tween.MaterialProperty     (m, propId, settingsVector4) : default; }

                    case TweenType.EulerAngles: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.EulerAngles(tweenTarget, settingsVector3) : default; }
                    case TweenType.LocalEulerAngles: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalEulerAngles(tweenTarget, settingsVector3) : default; }
                    case TweenType.GlobalTimeScale: {
                        if (!ctx.useUnscaledTime) {
                            Debug.LogError($"Please enable {nameof(TweenAnimation)}.{nameof(ctx.useUnscaledTime)} to animate Time.timeScale correctly.");
                        }
                        var settings = settingsFloat;
                        settings.settings.useUnscaledTime = true;
                        return Tween.GlobalTimeScale(settings);
                    }

                    #if UNITY_2021_1_OR_NEWER
                    case TweenType.MaterialPropertyBlockColorProperty:   { return GetUnityTarget(out Renderer r, ref err, i) && GetPropId  (out int propId,      ref err, i) ? Tween.MaterialPropertyBlockColor           (r, propId,   settingsColor,   materialIndex) : default; }
                    case TweenType.MaterialPropertyBlockAlphaProperty:   { return GetUnityTarget(out Renderer r, ref err, i) && GetPropId  (out int propId,      ref err, i) ? Tween.MaterialPropertyBlockAlpha           (r, propId,   settingsFloat,   materialIndex) : default; }
                    case TweenType.MaterialPropertyBlockProperty:        { return GetUnityTarget(out Renderer r, ref err, i) && GetPropId  (out int propId,      ref err, i) ? Tween.MaterialPropertyBlockProperty        (r, propId,   settingsFloat,   materialIndex) : default; }
                    case TweenType.MaterialPropertyBlockPropertyVector4: { return GetUnityTarget(out Renderer r, ref err, i) && GetPropId  (out int propId,      ref err, i) ? Tween.MaterialPropertyBlockProperty (r, propId,   settingsVector4, materialIndex) : default; }
                    case TweenType.MaterialPropertyBlockTextureScale:    { return GetUnityTarget(out Renderer r, ref err, i) && GetPropName(out string propName, ref err) ? Tween.MaterialPropertyBlockTextureScale    (r, propName, settingsVector2, materialIndex) : default; }
                    case TweenType.MaterialPropertyBlockTextureOffset:   { return GetUnityTarget(out Renderer r, ref err, i) && GetPropName(out string propName, ref err) ? Tween.MaterialPropertyBlockTextureOffset   (r, propName, settingsVector2, materialIndex) : default; }
                    #endif

                    #if TEXT_MESH_PRO_INSTALLED
                    case TweenType.TextMaxVisibleCharactersNormalized: { return GetUnityTarget<TMP_Text>(out var tweenTarget, ref err, i) ? Tween.TextMaxVisibleCharactersNormalized(tweenTarget, settingsFloat) : default; }
                    #endif

                    case TweenType.PositionAdditive:      { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.PositionAdditive     (tweenTarget, endValue.vector3, settingsVector3.settings) : default; }
                    case TweenType.LocalPositionAdditive: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalPositionAdditive(tweenTarget, endValue.vector3, settingsVector3.settings) : default; }
                    case TweenType.ScaleAdditive:         { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.ScaleAdditive        (tweenTarget, endValue.vector3, settingsVector3.settings) : default; }
                    case TweenType.RotationAdditive:      { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.RotationAdditive     (tweenTarget, endValue.vector3, settingsVector3.settings) : default; }
                    case TweenType.LocalRotationAdditive: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalRotationAdditive(tweenTarget, endValue.vector3, settingsVector3.settings) : default; }

                    // CODE GENERATOR BEGIN
                    case TweenType.LightRange: { return GetUnityTarget<Light>(out var tweenTarget, ref err, i) ? Tween.LightRange(tweenTarget, settingsFloat) : default; }
                    case TweenType.LightShadowStrength: { return GetUnityTarget<Light>(out var tweenTarget, ref err, i) ? Tween.LightShadowStrength(tweenTarget, settingsFloat) : default; }
                    case TweenType.LightIntensity: { return GetUnityTarget<Light>(out var tweenTarget, ref err, i) ? Tween.LightIntensity(tweenTarget, settingsFloat) : default; }
                    case TweenType.LightColor: { return GetUnityTarget<Light>(out var tweenTarget, ref err, i) ? Tween.LightColor(tweenTarget, settingsColor) : default; }
                    case TweenType.CameraOrthographicSize: { return GetUnityTarget<Camera>(out var tweenTarget, ref err, i) ? Tween.CameraOrthographicSize(tweenTarget, settingsFloat) : default; }
                    case TweenType.CameraBackgroundColor: { return GetUnityTarget<Camera>(out var tweenTarget, ref err, i) ? Tween.CameraBackgroundColor(tweenTarget, settingsColor) : default; }
                    case TweenType.CameraAspect: { return GetUnityTarget<Camera>(out var tweenTarget, ref err, i) ? Tween.CameraAspect(tweenTarget, settingsFloat) : default; }
                    case TweenType.CameraFarClipPlane: { return GetUnityTarget<Camera>(out var tweenTarget, ref err, i) ? Tween.CameraFarClipPlane(tweenTarget, settingsFloat) : default; }
                    case TweenType.CameraFieldOfView: { return GetUnityTarget<Camera>(out var tweenTarget, ref err, i) ? Tween.CameraFieldOfView(tweenTarget, settingsFloat) : default; }
                    case TweenType.CameraNearClipPlane: { return GetUnityTarget<Camera>(out var tweenTarget, ref err, i) ? Tween.CameraNearClipPlane(tweenTarget, settingsFloat) : default; }
                    case TweenType.CameraPixelRect: { return GetUnityTarget<Camera>(out var tweenTarget, ref err, i) ? Tween.CameraPixelRect(tweenTarget, settingsRect) : default; }
                    case TweenType.CameraRect: { return GetUnityTarget<Camera>(out var tweenTarget, ref err, i) ? Tween.CameraRect(tweenTarget, settingsRect) : default; }
                    case TweenType.LocalRotation: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalRotation(tweenTarget, settingsVector3) : default; }
                    case TweenType.ScaleUniform: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.Scale(tweenTarget, settingsFloat) : default; }
                    case TweenType.Rotation: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.Rotation(tweenTarget, settingsVector3) : default; }
                    case TweenType.Position: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.Position(tweenTarget, settingsVector3) : default; }
                    case TweenType.PositionX: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.PositionX(tweenTarget, settingsFloat) : default; }
                    case TweenType.PositionY: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.PositionY(tweenTarget, settingsFloat) : default; }
                    case TweenType.PositionZ: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.PositionZ(tweenTarget, settingsFloat) : default; }
                    case TweenType.LocalPosition: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalPosition(tweenTarget, settingsVector3) : default; }
                    case TweenType.LocalPositionX: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalPositionX(tweenTarget, settingsFloat) : default; }
                    case TweenType.LocalPositionY: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalPositionY(tweenTarget, settingsFloat) : default; }
                    case TweenType.LocalPositionZ: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalPositionZ(tweenTarget, settingsFloat) : default; }
                    case TweenType.RotationQuaternion: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.Rotation(tweenTarget, settingsQuaternion) : default; }
                    case TweenType.LocalRotationQuaternion: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalRotation(tweenTarget, settingsQuaternion) : default; }
                    case TweenType.Scale: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.Scale(tweenTarget, settingsVector3) : default; }
                    case TweenType.ScaleX: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.ScaleX(tweenTarget, settingsFloat) : default; }
                    case TweenType.ScaleY: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.ScaleY(tweenTarget, settingsFloat) : default; }
                    case TweenType.ScaleZ: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.ScaleZ(tweenTarget, settingsFloat) : default; }
                    case TweenType.ColorSpriteRenderer: { return GetUnityTarget<SpriteRenderer>(out var tweenTarget, ref err, i) ? Tween.Color(tweenTarget, settingsColor) : default; }
                    case TweenType.AlphaSpriteRenderer: { return GetUnityTarget<SpriteRenderer>(out var tweenTarget, ref err, i) ? Tween.Alpha(tweenTarget, settingsFloat) : default; }
                    #if !UNITY_2019_1_OR_NEWER || UNITY_UGUI_INSTALLED
                    case TweenType.UISliderValue: { return GetUnityTarget<Slider>(out var tweenTarget, ref err, i) ? Tween.UISliderValue(tweenTarget, settingsFloat) : default; }
                    case TweenType.UINormalizedPosition: { return GetUnityTarget<ScrollRect>(out var tweenTarget, ref err, i) ? Tween.UINormalizedPosition(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIHorizontalNormalizedPosition: { return GetUnityTarget<ScrollRect>(out var tweenTarget, ref err, i) ? Tween.UIHorizontalNormalizedPosition(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIVerticalNormalizedPosition: { return GetUnityTarget<ScrollRect>(out var tweenTarget, ref err, i) ? Tween.UIVerticalNormalizedPosition(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIPivotX: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIPivotX(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIPivotY: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIPivotY(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIPivot: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIPivot(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIAnchorMax: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIAnchorMax(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIAnchorMin: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIAnchorMin(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIAnchoredPosition3D: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIAnchoredPosition3D(tweenTarget, settingsVector3) : default; }
                    case TweenType.UIAnchoredPosition3DX: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIAnchoredPosition3DX(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIAnchoredPosition3DY: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIAnchoredPosition3DY(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIAnchoredPosition3DZ: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIAnchoredPosition3DZ(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIEffectDistance: { return GetUnityTarget<Shadow>(out var tweenTarget, ref err, i) ? Tween.UIEffectDistance(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIAlphaShadow: { return GetUnityTarget<Shadow>(out var tweenTarget, ref err, i) ? Tween.Alpha(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIColorShadow: { return GetUnityTarget<Shadow>(out var tweenTarget, ref err, i) ? Tween.Color(tweenTarget, settingsColor) : default; }
                    case TweenType.UIPreferredSize: { return GetUnityTarget<LayoutElement>(out var tweenTarget, ref err, i) ? Tween.UIPreferredSize(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIPreferredWidth: { return GetUnityTarget<LayoutElement>(out var tweenTarget, ref err, i) ? Tween.UIPreferredWidth(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIPreferredHeight: { return GetUnityTarget<LayoutElement>(out var tweenTarget, ref err, i) ? Tween.UIPreferredHeight(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIFlexibleSize: { return GetUnityTarget<LayoutElement>(out var tweenTarget, ref err, i) ? Tween.UIFlexibleSize(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIFlexibleWidth: { return GetUnityTarget<LayoutElement>(out var tweenTarget, ref err, i) ? Tween.UIFlexibleWidth(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIFlexibleHeight: { return GetUnityTarget<LayoutElement>(out var tweenTarget, ref err, i) ? Tween.UIFlexibleHeight(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIMinSize: { return GetUnityTarget<LayoutElement>(out var tweenTarget, ref err, i) ? Tween.UIMinSize(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIMinWidth: { return GetUnityTarget<LayoutElement>(out var tweenTarget, ref err, i) ? Tween.UIMinWidth(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIMinHeight: { return GetUnityTarget<LayoutElement>(out var tweenTarget, ref err, i) ? Tween.UIMinHeight(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIColorGraphic: { return GetUnityTarget<Graphic>(out var tweenTarget, ref err, i) ? Tween.Color(tweenTarget, settingsColor) : default; }
                    case TweenType.UIAnchoredPosition: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIAnchoredPosition(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIAnchoredPositionX: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIAnchoredPositionX(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIAnchoredPositionY: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIAnchoredPositionY(tweenTarget, settingsFloat) : default; }
                    case TweenType.UISizeDelta: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UISizeDelta(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIAlphaCanvasGroup: { return GetUnityTarget<CanvasGroup>(out var tweenTarget, ref err, i) ? Tween.Alpha(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIAlphaGraphic: { return GetUnityTarget<Graphic>(out var tweenTarget, ref err, i) ? Tween.Alpha(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIFillAmount: { return GetUnityTarget<Image>(out var tweenTarget, ref err, i) ? Tween.UIFillAmount(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIOffsetMin: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIOffsetMin(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIOffsetMinX: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIOffsetMinX(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIOffsetMinY: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIOffsetMinY(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIOffsetMax: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIOffsetMax(tweenTarget, settingsVector2) : default; }
                    case TweenType.UIOffsetMaxX: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIOffsetMaxX(tweenTarget, settingsFloat) : default; }
                    case TweenType.UIOffsetMaxY: { return GetUnityTarget<RectTransform>(out var tweenTarget, ref err, i) ? Tween.UIOffsetMaxY(tweenTarget, settingsFloat) : default; }
                    #endif
                    #if !UNITY_2019_1_OR_NEWER || PHYSICS_MODULE_INSTALLED
                    case TweenType.RigidbodyMoveRotation: { return GetUnityTarget<Rigidbody>(out var tweenTarget, ref err, i) ? Tween.RigidbodyMoveRotation(tweenTarget, settingsVector3) : default; }
                    case TweenType.RigidbodyMovePosition: { return GetUnityTarget<Rigidbody>(out var tweenTarget, ref err, i) ? Tween.RigidbodyMovePosition(tweenTarget, settingsVector3) : default; }
                    case TweenType.RigidbodyMoveRotationQuaternion: { return GetUnityTarget<Rigidbody>(out var tweenTarget, ref err, i) ? Tween.RigidbodyMoveRotation(tweenTarget, settingsQuaternion) : default; }
                    #endif
                    #if !UNITY_2019_1_OR_NEWER || PHYSICS2D_MODULE_INSTALLED
                    case TweenType.RigidbodyMovePosition2D: { return GetUnityTarget<Rigidbody2D>(out var tweenTarget, ref err, i) ? Tween.RigidbodyMovePosition(tweenTarget, settingsVector2) : default; }
                    case TweenType.RigidbodyMoveRotation2D: { return GetUnityTarget<Rigidbody2D>(out var tweenTarget, ref err, i) ? Tween.RigidbodyMoveRotation(tweenTarget, settingsFloat) : default; }
                    #endif
                    case TweenType.MaterialColor: { return GetUnityTarget<Material>(out var tweenTarget, ref err, i) ? Tween.MaterialColor(tweenTarget, settingsColor) : default; }
                    case TweenType.MaterialAlpha: { return GetUnityTarget<Material>(out var tweenTarget, ref err, i) ? Tween.MaterialAlpha(tweenTarget, settingsFloat) : default; }
                    case TweenType.MaterialMainTextureOffset: { return GetUnityTarget<Material>(out var tweenTarget, ref err, i) ? Tween.MaterialMainTextureOffset(tweenTarget, settingsVector2) : default; }
                    case TweenType.MaterialMainTextureScale: { return GetUnityTarget<Material>(out var tweenTarget, ref err, i) ? Tween.MaterialMainTextureScale(tweenTarget, settingsVector2) : default; }
                    #if !UNITY_2019_1_OR_NEWER || AUDIO_MODULE_INSTALLED
                    case TweenType.AudioVolume: { return GetUnityTarget<AudioSource>(out var tweenTarget, ref err, i) ? Tween.AudioVolume(tweenTarget, settingsFloat) : default; }
                    case TweenType.AudioPitch: { return GetUnityTarget<AudioSource>(out var tweenTarget, ref err, i) ? Tween.AudioPitch(tweenTarget, settingsFloat) : default; }
                    case TweenType.AudioPanStereo: { return GetUnityTarget<AudioSource>(out var tweenTarget, ref err, i) ? Tween.AudioPanStereo(tweenTarget, settingsFloat) : default; }
                    #endif
                    #if UI_ELEMENTS_MODULE_INSTALLED
                    #endif
                    #if TEXT_MESH_PRO_INSTALLED
                    case TweenType.TextMaxVisibleCharacters: { return GetUnityTarget<TMP_Text>(out var tweenTarget, ref err, i) ? Tween.TextMaxVisibleCharacters(tweenTarget, settingsInt) : default; }
                    case TweenType.TextFontSize: { return GetUnityTarget<TMP_Text>(out var tweenTarget, ref err, i) ? Tween.TextFontSize(tweenTarget, settingsFloat) : default; }
                    #endif
                    default:
                        throw new Exception($"Unsupported tween type: {tweenType}. Please install necessary packages (TextMeshPro, UGUI, etc.) or use a newer version of Unity.");
                }
            }
        }
    }
}
#endif // PRIME_TWEEN_PRO
